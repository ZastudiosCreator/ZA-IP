# Changelog

All notable changes to this project will be documented in this file.

## [1.5.0] - 2026-05-04

### Fixed

- `hooks/tk-multi-publish2/shot/shot_validation.py`: added
  `_iter_fcurves(action)` helper to support Blender 5+ layered
  animation structure (`action.layers[].strips[].channelbags[].fcurves`)
  while maintaining backward compatibility with legacy
  `action.fcurves`.
- `hooks/tk-multi-publish2/shot/shot_validation.py`: typo fix
  `scene.collection.childrenq` → `scene.collection.children` in the
  collection-naming check.
- `hooks/tk-multi-publish2/shot/playblast.py`: Blender 5 split
  `image_settings` into `media_type` (`IMAGE`/`VIDEO`) + `file_format`;
  set `media_type = 'VIDEO'` before assigning `file_format = 'FFMPEG'`,
  guarded by `hasattr` for pre-5 versions.
- `python/shot_builder/__init__.py`: editorial reference resolver
  was filtering `published_file_type.code` on `"Blender Project File"`
  only, which silently rejected every publish on projects where
  tk-blender registers the type as `"Blender Scene"` (current type
  code under Blender 5). Now accepts both via module constant
  `BLENDER_PUBLISH_TYPES = ("Blender Scene", "Blender Project File")`.

### Added

- `docs/` — config documentation. `docs/index.md` is the entry point;
  `docs/python/shot_builder.md` documents the editorial-reference
  resolution rules, configuration toggles, and error messages.
  Folders `docs/env/` and `docs/hooks/` are reserved for later.
- `.markdownlint.json` — sets `MD024: { siblings_only: true }` so
  per-version `### Added` / `### Changed` headings in `CHANGELOG.md`
  stop tripping the duplicate-heading rule.
- `docs/snippets/check_editorial_shots.py` — Blender-runnable debug
  script that lists every shot in the current shot's sequence and
  episode, flags Editorial-template shots, and dumps each editorial
  shot's publishes (type, step, task, status). Run from the
  Scripting tab when the shot builder fails to find a reference.

### Changed

- `hooks/tk-multi-publish2/shot/playblast.py`: added rollback on
  failure. Any error in the playblast publish chain (render, copy,
  Version create/link, upload) now deletes the Version this hook
  created (if any), the parent PublishedFile and its on-disk `.blend`,
  and the publish-side `.mp4` — so retry no longer fails on
  "publish already exists at this path". Each rollback step is
  independently exception-guarded and never re-raises.
- `python/shot_builder/__init__.py`: reference shot resolution no
  longer matches shots whose `code` contains `"layout"`. The builder
  now picks an Editorial shot (`task_template = "Animaj - Editorial"`)
  that has a Blender publish on a Layout-step task. To avoid silently
  picking the wrong reference, exactly one match is required: either
  one valid Editorial shot in the same sequence, or — if none in the
  sequence — exactly one elsewhere in the same episode. Two or more
  matches in either tier returns an error. Added module flag
  `VALIDATED_ONLY` (default `False`) and a per-call `validated_only`
  argument on `get_layout_scene_from_context()` to restrict the search
  to reviewed/approved publishes (`sg_status_list` in `vwd`/`apr`).

## [1.4.0] - 2026-04-30

### Added

- `python/sg_utils/` — shared ShotGrid helpers;
  `get_shot_info(shot_name, episode=None, sequence=None)` returns
  shot / project / assets / steps with publish + work directories
  (resolved via SGTK templates) and latest publishes per file type.
  Steps preserve the order configured in ShotGrid (sorted by
  `Step.list_order`).
- `python/layout_builder/` — pure-bpy layout builder; creates a
  `shot_cam` in the `CAM` collection with the latest animatic
  (`ant`) playblast as a `MOVIE_CLIP` background, falling back to
  storyboard (`stb`) when no animatic playblast exists

### Changed

- `hooks/tk-multi-workfiles2/scene_operation_tk-blender.py`: on
  layout-step new file, shots whose `task_template` is
  `Animaj - Editorial` (case-insensitive) now call
  `layout_builder.build_layout_from_context(ctx)`; added
  flow-trace logging across `execute()` / `_post_reset` /
  `_post_open` / `_process_shot`
- `env/includes/engine_locations.yml`: `tk-blender` descriptor
  switched from `type: path` (`C:\Animaj\tk-blender\7b17b6b`) to
  `type: dev` (`m:\users\emile.reynaud\dev\tk-blender`) for
  Blender 5 compatibility

## [1.3.1] - 2026-04-17

### Changed

- `hooks/tk-multi-workfiles2/scene_operation_tk-blender.py`: shot
  build now only triggers for shots using task template ID 31
  (`Animaj - Shot`)

## [1.3.0] - 2026-04-17

### Added

- `python/shot_builder/` — shared module folder inside the config,
  replaces the `tk-framework-process` framework

### Changed

- `env/includes/frameworks.yml`: removed `tk-framework-process`
  descriptor; `shot_builder` is now imported directly from
  `python/shot_builder/` via hook helper
- `hooks/shot_build.py`: `BLENDER_EXE` reads from `BLENDER_EXE`
  env var with fallback to default install path
- `hooks/tk-multi-workfiles2/scene_operation_tk-blender.py`:
  replaced `load_framework()` with `_import_config_module()` helper
  resolving `python/` from `self.disk_location`; asset library paths
  now derived from `engine.sgtk.roots["primary"]`

### Notes

To import any module from `python/` in a hook, use the
`_import_config_module(name)` pattern: it resolves the config's
`python/` folder relative to `self.disk_location` (the hook's own
directory) and inserts it into `sys.path` before importing. Copy the
helper method into any hook that needs it.

## [1.2.0] - 2026-04-17

### Added

- `misc` static folder (work + publish) for shot steps — off-pipeline,
  always created with the shot structure

## [1.1.0] - 2026-04-17

### Added

- New editorial folder structure schema with season/episode hierarchy
- Shot type variants: `shot_default`, `shot_editorial`, `shot_layout`
- Step-based folder organization per shot type (blender, playblast, task)

### Changed

- Restructured production schema from generic shot folders to typed shot folders
- Moved editorial folders from standalone publish/work to
  production-integrated structure

### Removed

- Legacy `shot.yml` schema (replaced by shot type variants)
- Standalone editorial season/episode folders under publish/work

## [1.0.0] - 2026-04-17

Initial release based on animaj_main branch.

### Added

- added .vscode to gitignore
- changelog to keep track of features and changes
- Za Studios modifications with new schema
- Custom pipeline configuration for ShotGrid Toolkit
- Blender engine integration (tk-blender)
- Custom hooks for workfiles, publishing, and scene operations
