import sgtk

EDITORIAL = "Animaj - Editorial"

eng = sgtk.platform.current_engine()
sg = eng.shotgun
ctx = eng.context

print("=" * 60)
print(f"context entity: {ctx.entity}")
print("=" * 60)

shot = sg.find_one(
    "Shot",
    [["id", "is", ctx.entity["id"]]],
    ["code", "sg_sequence", "sg_episode", "task_template"],
)
print(f"current shot:    {shot.get('code')!r}")
print(f"  sg_sequence:   {shot.get('sg_sequence')}")
print(f"  sg_episode:    {shot.get('sg_episode')}")
print(f"  task_template: {shot.get('task_template')}")

sequence = shot.get("sg_sequence")
episode  = shot.get("sg_episode")

# ---- Tier 1: same sequence, any task_template (broader than the resolver) ----
print("\n--- Tier 1: ALL shots in same sequence ---")
seq_shots = sg.find(
    "Shot",
    [["sg_sequence", "is", sequence]],
    ["code", "task_template"],
) if sequence else []
for s in seq_shots:
    tt = (s.get("task_template") or {}).get("name")
    flag = "  <-- EDITORIAL" if tt == EDITORIAL else ""
    print(f"  {s['id']:>6}  {s['code']!r}  template={tt!r}{flag}")

# ---- Tier 2: same episode ----
print("\n--- Tier 2: ALL shots in same episode (any sequence) ---")
ep_shots = sg.find(
    "Shot",
    [["sg_episode", "is", episode]],
    ["code", "sg_sequence", "task_template"],
) if episode else []
for s in ep_shots:
    tt = (s.get("task_template") or {}).get("name")
    seq = (s.get("sg_sequence") or {}).get("name")
    flag = "  <-- EDITORIAL" if tt == EDITORIAL else ""
    print(f"  {s['id']:>6}  {s['code']!r}  seq={seq!r}  template={tt!r}{flag}")

# ---- For each editorial shot found, list its Blender publishes ----
editorials = [s for s in (seq_shots + ep_shots) if (s.get("task_template") or {}).get("name") == EDITORIAL]
print(f"\n--- Editorial shots found: {len(editorials)} ---")
for s in editorials:
    print(f"\nEditorial shot {s['code']!r} (id={s['id']}):")
    publishes = sg.find(
        "PublishedFile",
        [["entity", "is", s]],
        ["code", "version_number", "sg_status_list",
         "published_file_type.PublishedFileType.code",
         "task.Task.step.Step.code",
         "task.Task.step.Step.short_name",
         "task.Task.content"],
        order=[{"field_name": "version_number", "direction": "desc"}],
    )
    if not publishes:
        print("  (no publishes at all)")
        continue
    for p in publishes:
        pft  = p.get("published_file_type.PublishedFileType.code")
        step = p.get("task.Task.step.Step.code")
        short= p.get("task.Task.step.Step.short_name")
        task = p.get("task.Task.content")
        print(f"  v{p.get('version_number')}  type={pft!r}  step.code={step!r}  step.short={short!r}  task={task!r}  status={p.get('sg_status_list')!r}")
