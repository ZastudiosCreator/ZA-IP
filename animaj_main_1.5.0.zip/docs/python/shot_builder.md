# `shot_builder`

Builds an animation shot `.blend` by opening a sibling **Editorial**
shot's layout publish as the base scene, then applying the built
shot's frame range and FPS.

Source: [`python/shot_builder/__init__.py`](../../python/shot_builder/__init__.py)

## When it runs

Triggered by [`hooks/tk-multi-workfiles2/scene_operation_tk-blender.py`](../../hooks/tk-multi-workfiles2/scene_operation_tk-blender.py)
when a Workfiles2 "new file" / "reset" happens on a shot whose
`task_template` is **`Animaj - Shot`** (id `31`). The hook calls:

```python
shot_builder.build_shot_from_context(ctx)
```

It can also be invoked headlessly from `scripts/build_shot_runner.py`
or directly via `build_shot(...)` with explicit arguments.

## Reference resolution

The reference scene is **not** the built shot itself — it's the latest
Blender publish on a Layout-step task of a sibling **Editorial shot**
(`task_template = "Animaj - Editorial"`).

To prevent silently picking the wrong reference, exactly one match is
required. The lookup is two-tier:

1. **Tier 1 — same sequence.** Find Editorial shots in the same
   `sg_sequence` as the built shot. Keep only those that have a
   Blender publish on a Layout-step task ("valid"). 
   - **1 valid** → use it.
   - **2 or more valid** → error _"ambiguous reference"_, no fallback.
   - **0 valid** → fall through to tier 2.
2. **Tier 2 — same episode, different sequence.** Find Editorial
   shots with the same `sg_episode` but `sg_sequence != current`. Keep
   only those that are valid.
   - **1 valid** → use it.
   - **2 or more valid** → error _"ambiguous reference"_, no fallback.
   - **0 valid** → error _"no Editorial shot ... found"_.

A shot with no `sg_sequence` and no `sg_episode` is an immediate
error.

### What counts as a "Layout publish"

A `PublishedFile` on the candidate shot where:

- `published_file_type.code == "Blender Project File"`, AND
- the publish's task's `Step.code` or `Step.short_name` contains
  `"layout"` (case-insensitive).

When several publishes match, the latest by `version_number` (then
`id`) wins.

## Configuration

| Symbol | Default | Effect |
| --- | --- | --- |
| `VALIDATED_ONLY` (module constant) | `False` | When `True`, only publishes with `sg_status_list` in `vwd` (viewed) or `apr` (approved) are accepted. |
| `EDITORIAL_TEMPLATE_NAME` | `"Animaj - Editorial"` | The `task_template.code` used to identify Editorial shots. |
| `validated_only=` (kwarg on `get_layout_scene_from_context`) | `None` | Overrides `VALIDATED_ONLY` for a single call. |

To require validated references for a build session without editing
the module, call:

```python
shot_builder.get_layout_scene_from_context(ctx, validated_only=True)
```

## Public API

```python
build_shot_from_context(ctx)
```
Resolve the editorial reference from `ctx`, then call `build_shot(...)`
with the built shot's `sg_cut_in` / `sg_cut_out` and the project's
`sg_fps`.

```python
build_shot(
    sequence_scene_path,  # str | None — base scene to open
    frame_start,          # int        — sg_cut_in
    frame_end,            # int        — sg_cut_out
    fps,                  # int
    asset_list,           # list[str]  — assets to keep (currently unused: clean step is disabled)
    output_path=None,     # str | None — save target; None = stay in memory
)
```

```python
get_layout_scene_from_context(ctx, validated_only=None) -> str | None
```
Resolves the editorial layout publish path. Returns `None` and prints
a `[shot_builder] ERROR: ...` line on every failure mode listed above.

## Errors and how to read them

All log lines are prefixed with `[shot_builder]`.

| Message | Meaning |
| --- | --- |
| `context is not a Shot context` | The hook fired outside a Shot context. |
| `current shot has no sequence or episode` | The built shot is detached from its parents — fix in ShotGrid. |
| `ambiguous reference — N Editorial shots ... in the same sequence` | Two or more sequence-level Editorial shots have a Layout publish. Either remove the stale publish, or split the editorial template assignments. |
| `ambiguous reference — N Editorial shots ... elsewhere in the episode` | Same as above but at the episode tier. |
| `no Editorial shot with a Layout publish found ...` | No valid candidate in either tier. Either no Editorial shot exists, or none has a Layout publish yet. |
