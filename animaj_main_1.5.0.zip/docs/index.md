# animaj_dev

Dev variant of `tk-config-default2` for Animaj. This is where new
behavior is iterated before being promoted to `animaj_main`.

## Layout

| Path | Contents |
| --- | --- |
| `core/` | SGTK core + folder/file schema (templates) |
| `env/` | App and engine bundle configuration (YAML) |
| `hooks/` | Project-side hook implementations |
| `python/` | In-config Python modules used by hooks and headless scripts |

## Python modules

- [`python/shot_builder/`](python/shot_builder.md) — builds an
  animation shot `.blend` from a sibling Editorial shot's layout
  publish.
- `python/layout_builder/` — pure-bpy layout builder (creates a
  `shot_cam` with the latest animatic/storyboard playblast as
  background). _Doc TBD._
- `python/sg_utils/` — shared ShotGrid helpers
  (`get_shot_info(shot_name, episode=None, sequence=None)`).
  _Doc TBD._

## Hooks

_Doc TBD._ See `hooks/` for project-side hook implementations.
The most active one is
`hooks/tk-multi-workfiles2/scene_operation_tk-blender.py`, which
dispatches to `shot_builder` and `layout_builder` based on the shot's
task template.

## Environments

_Doc TBD._ See `env/` for engine and app configuration.

## Changes

See [`CHANGELOG.md`](../CHANGELOG.md) at the config root for the full
version history.
