"""
Pure bpy layout builder module.

Receives all SG data via sg_utils.get_shot_info and uses bpy to configure
a freshly-reset Blender scene for a Layout step.

Currently builds:
  - a 'shot_cam' camera in the 'CAM' collection
  - the latest animatic (ant) or storyboard (stb) playblast as a MOVIE_CLIP
    background on that camera (animatic preferred; storyboard fallback)

Called from:
  - hooks/tk-multi-workfiles2/scene_operation_tk-blender.py (interactive, via timer)

Quick test inside Blender (with a shot context):

    import sys
    sys.path.insert(0, r"M:\\users\\emile.reynaud\\dev\\tk-config-default2\\animaj_dev\\python")
    import layout_builder, importlib
    importlib.reload(layout_builder)
    import sgtk
    layout_builder.build_layout_from_context(sgtk.platform.current_engine().context)
"""

import os
import re

import bpy

# Steps to look at for a playblast, in priority order.
# Animatic first, storyboard fallback.
PLAYBLAST_STEP_PRIORITY = ("ant", "stb")

_VERSION_MP4_RE = re.compile(r".*_v(\d+)\.mp4$", re.IGNORECASE)


def build_layout_from_context(ctx):
    """
    Configure the current Blender scene for a Layout step using SG data
    resolved via sg_utils.get_shot_info.

    :param ctx: SGTK context (must contain a Shot entity)
    """
    print(f"[layout_builder] build_layout_from_context entered (ctx={ctx})")

    if not ctx or not ctx.entity or ctx.entity.get("type") != "Shot":
        print("[layout_builder] ERROR: context is not a Shot context")
        return

    import sg_utils  # sibling module on the same python path

    shot_code = ctx.entity.get("name")
    if not shot_code:
        print("[layout_builder] ERROR: shot has no name on context")
        return

    print(f"[layout_builder] Resolving shot info for code={shot_code!r}")
    info = sg_utils.get_shot_info(shot_code)
    if not info:
        return

    print(f"[layout_builder] Shot info resolved; steps: {list((info.get('steps') or {}).keys())}")
    setup_playblast_camera(info)


def setup_playblast_camera(
    info,
    cam_name="shot_cam",
    cam_collection_name="CAM",
):
    """
    Create a camera and attach the latest animatic/storyboard playblast as a
    MOVIE_CLIP background. Skips silently if a camera with the same name
    already exists.

    :param info: dict from sg_utils.get_shot_info
    :param cam_name: name for the camera object/data
    :param cam_collection_name: target collection (created if missing)
    """
    if cam_name in bpy.data.objects:
        print(f"[layout_builder] {cam_name} already exists — skipping")
        return

    playblast = find_latest_playblast(info)
    if not playblast:
        print("[layout_builder] No animatic/storyboard playblast found")
        return

    # Camera object + data
    cam_data = bpy.data.cameras.new(name=cam_name)
    cam_obj = bpy.data.objects.new(cam_name, cam_data)

    # Place into target collection (create if missing — workfiles2 hook
    # currently creates 'CAM' only when a camera asset is linked, so we
    # need to handle the absent case ourselves).
    target = bpy.data.collections.get(cam_collection_name)
    if not target:
        target = bpy.data.collections.new(cam_collection_name)
        bpy.context.scene.collection.children.link(target)
    target.objects.link(cam_obj)

    # Active scene camera
    bpy.context.scene.camera = cam_obj

    # MOVIE_CLIP background image
    cam_data.show_background_images = True
    bg = cam_data.background_images.new()
    bg.source = 'MOVIE_CLIP'
    bg.clip = bpy.data.movieclips.load(playblast)
    bg.display_depth = 'BACK'

    print(f"[layout_builder] Loaded playblast as background: {playblast}")


def find_latest_playblast(info, step_priority=PLAYBLAST_STEP_PRIORITY):
    """
    Walk `step_priority` in order; for the first step that has a publish_dir
    with a non-empty <publish_dir>/playblast folder, return the highest-versioned
    `_v###.mp4` file in that folder.

    Returns None if no candidate is found.

    :param info: dict from sg_utils.get_shot_info
    :param step_priority: iterable of step short_names, in priority order
    :return: str | None — local file path of the chosen playblast
    """
    steps = info.get("steps") or {}

    for short_name in step_priority:
        bucket = steps.get(short_name)
        if not bucket:
            print(f"[layout_builder] step '{short_name}' not on shot; skipping")
            continue

        publish_dir = bucket.get("publish_dir")
        if not publish_dir:
            print(
                f"[layout_builder] step '{short_name}' has no publish_dir "
                f"(template did not resolve); skipping"
            )
            continue

        playblast_dir = os.path.join(publish_dir, "playblast")
        latest = _latest_versioned_mp4(playblast_dir)
        if latest:
            print(f"[layout_builder] Using '{short_name}' playblast: {latest}")
            return latest

        print(f"[layout_builder] No mp4 in {playblast_dir}")

    return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _latest_versioned_mp4(folder):
    """Return the .mp4 in `folder` with the highest _v### suffix, or None."""
    if not os.path.isdir(folder):
        return None

    best_version = -1
    best_path = None

    for entry in os.listdir(folder):
        match = _VERSION_MP4_RE.match(entry)
        if not match:
            continue
        full = os.path.join(folder, entry)
        if not os.path.isfile(full):
            continue
        version = int(match.group(1))
        if version > best_version:
            best_version = version
            best_path = full

    return best_path
