"""
Shared ShotGrid (shotgun_api3) helpers used by builders.

Pulls together everything a builder needs about a shot in one call:
  - the shot entity (cut info, season/episode/sequence as strings)
  - project metadata (fps, tank_name)
  - all assets cast on the shot
  - every step that has a Task on the shot, with publish/work directory paths
    (resolved via SGTK templates) and the latest publish per file type

No bpy. Uses the active SGTK engine for `engine.shotgun` (shotgun_api3) and
`engine.sgtk` (template resolution).

Quick test inside Blender (with a shot context):

import sys
sys.path.insert(0, r"M:\\users\\emile.reynaud\\dev\\tk-config-default2\\animaj_dev\\python")
import sg_utils, json
print(json.dumps(sg_utils.get_shot_info("SH-DEV"), indent=2, default=str))
"""

import sgtk


def get_shot_info(shot_name, episode=None, sequence=None):
    """
    Resolve a Shot by code (and optionally episode/sequence) and return a dict
    with everything builders need to operate on it.

    Shot codes may not be unique across episodes/sequences — pass `episode`
    and/or `sequence` if a bare `shot_name` matches more than one Shot.

    :param shot_name: str — Shot.code (e.g. "SH-DEV")
    :param episode:   str | None — value of Shot.sg_episode to disambiguate
    :param sequence:  str | None — value of Shot.sg_sequence to disambiguate

    :return: dict | None — None if the shot is not found or the lookup is
                           ambiguous (caller should disambiguate and retry).

    Returned dict structure::

        {
            "shot": {
                "id": int, "code": str,
                "cut_in": int|None, "cut_out": int|None,
                "season": str|None, "episode": str|None, "sequence": str|None,
            },
            "project": {
                "id": int, "name": str,
                "tank_name": str, "fps": int|None,
            },
            "assets": [{"id": int, "name": str, "type": str|None}, ...],
            "steps": {
                "<step_short_name>": {
                    "step":  {"id": int, "short_name": str, "name": str},
                    "tasks": [{"id": int, "name": str, "status": str|None}, ...],
                    "publish_dir": str|None,   # resolved via shot_publish_root
                    "work_dir":    str|None,   # resolved via shot_work_root
                    "publishes": [             # latest per published_file_type
                        {"type": str, "name": str,
                         "version": int, "path": str},
                        ...
                    ],
                },
                ...
            },
        }
    """
    engine = sgtk.platform.current_engine()
    if not engine:
        print("[sg_utils] ERROR: no active SGTK engine")
        return None

    sg = engine.shotgun
    tk = engine.sgtk

    # ---- 1. Find the shot --------------------------------------------------
    filters = [["code", "is", shot_name]]
    if episode:
        filters.append(["sg_episode", "is", episode])
    if sequence:
        filters.append(["sg_sequence", "is", sequence])

    shots = sg.find(
        "Shot",
        filters,
        [
            "code",
            "sg_season",
            "sg_episode",
            "sg_sequence",
            "sg_cut_in",
            "sg_cut_out",
            "project",
            "assets",
        ],
    )

    if not shots:
        print(
            f"[sg_utils] ERROR: no shot matched code={shot_name!r} "
            f"episode={episode!r} sequence={sequence!r}"
        )
        return None

    if len(shots) > 1:
        matches = [
            (s["id"], s.get("sg_episode"), s.get("sg_sequence")) for s in shots
        ]
        print(
            f"[sg_utils] ERROR: multiple shots match {shot_name!r} "
            f"— pass episode/sequence to disambiguate. "
            f"matches (id, episode, sequence): {matches}"
        )
        return None

    shot = shots[0]

    # ---- 2. Project metadata ----------------------------------------------
    project_link = shot.get("project") or {}
    project = (
        sg.find_one(
            "Project",
            [["id", "is", project_link.get("id")]],
            ["name", "tank_name", "sg_fps"],
        )
        if project_link.get("id")
        else None
    ) or {}

    # ---- 3. Assets --------------------------------------------------------
    asset_links = shot.get("assets") or []
    asset_full = []
    if asset_links:
        asset_full = sg.find(
            "Asset",
            [["id", "in", [a["id"] for a in asset_links]]],
            ["code", "sg_asset_type"],
        )
    assets = [
        {"id": a["id"], "name": a.get("code"), "type": a.get("sg_asset_type")}
        for a in asset_full
    ]

    # ---- 4. Tasks + Steps on this shot ------------------------------------
    # Sort by step list_order so the resulting `steps` dict mirrors the order
    # configured in ShotGrid (relies on Python 3.7+ dict insertion order).
    tasks = sg.find(
        "Task",
        [["entity", "is", shot]],
        [
            "content",
            "sg_status_list",
            "step",
            "step.Step.short_name",
            "step.Step.code",
            "step.Step.list_order",
        ],
        order=[
            {"field_name": "step.Step.list_order", "direction": "asc"},
            {"field_name": "id", "direction": "asc"},
        ],
    )

    # ---- 5. PublishedFiles for this shot (one query, group later) ---------
    publishes = sg.find(
        "PublishedFile",
        [["entity", "is", shot]],
        [
            "name",
            "version_number",
            "path",
            "task",
            "published_file_type.PublishedFileType.code",
        ],
        order=[
            {"field_name": "version_number", "direction": "desc"},
            {"field_name": "id", "direction": "desc"},
        ],
    )

    # ---- 6. Build steps dict ----------------------------------------------
    publish_root_tmpl = tk.templates.get("shot_publish_root")
    work_root_tmpl = tk.templates.get("shot_work_root")

    base_fields = {
        "Season":   _as_name(shot.get("sg_season")),
        "Episode":  _as_name(shot.get("sg_episode")),
        "Sequence": _as_name(shot.get("sg_sequence")),
        "Shot":     shot.get("code"),
    }

    # task_id -> step short_name (for matching publishes back to steps)
    task_to_step = {}
    steps = {}

    for task in tasks:
        short_name = task.get("step.Step.short_name")
        if not short_name:
            continue

        task_to_step[task["id"]] = short_name

        if short_name not in steps:
            steps[short_name] = {
                "step": {
                    "id":         (task.get("step") or {}).get("id"),
                    "short_name": short_name,
                    "name":       task.get("step.Step.code") or short_name,
                },
                "tasks": [],
                "publish_dir": _apply_root_template(
                    publish_root_tmpl, base_fields, short_name
                ),
                "work_dir": _apply_root_template(
                    work_root_tmpl, base_fields, short_name
                ),
                "publishes": [],
            }

        bucket = steps[short_name]
        bucket["tasks"].append({
            "id":     task.get("id"),
            "name":   task.get("content"),
            "status": task.get("sg_status_list"),
        })

    # latest publish per (step, file_type) — publishes already sorted desc
    seen = set()
    for pub in publishes:
        task_link = pub.get("task") or {}
        step_short = task_to_step.get(task_link.get("id"))
        if not step_short:
            continue

        file_type = pub.get(
            "published_file_type.PublishedFileType.code"
        ) or "Unknown"

        key = (step_short, file_type)
        if key in seen:
            continue
        seen.add(key)

        local_path = _extract_local_path(pub.get("path") or {})
        if not local_path:
            continue

        steps[step_short]["publishes"].append({
            "type":    file_type,
            "name":    pub.get("name"),
            "version": pub.get("version_number"),
            "path":    local_path,
        })

    # ---- 7. Assemble ------------------------------------------------------
    return {
        "shot": {
            "id":       shot["id"],
            "code":     shot.get("code"),
            "cut_in":   shot.get("sg_cut_in"),
            "cut_out":  shot.get("sg_cut_out"),
            "season":   _as_name(shot.get("sg_season")),
            "episode":  _as_name(shot.get("sg_episode")),
            "sequence": _as_name(shot.get("sg_sequence")),
        },
        "project": {
            "id":        project.get("id"),
            "name":      project.get("name"),
            "tank_name": project.get("tank_name"),
            "fps":       project.get("sg_fps"),
        },
        "assets": assets,
        "steps":  steps,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _apply_root_template(template, base_fields, step_short_name):
    """Resolve a shot_*_root template for the given step. None if any field is missing."""
    if not template:
        return None
    fields = dict(base_fields)
    fields["Step"] = step_short_name
    if any(v in (None, "") for v in fields.values()):
        return None
    try:
        return template.apply_fields(fields)
    except Exception as exc:
        print(
            f"[sg_utils] WARNING: failed to resolve template "
            f"{getattr(template, 'name', template)!r} with {fields}: {exc}"
        )
        return None


def _extract_local_path(path_data):
    """SG path dicts vary by platform; check common keys in priority order."""
    for key in (
        "local_path",
        "local_path_windows",
        "local_path_linux",
        "local_path_mac",
    ):
        value = path_data.get(key)
        if value:
            return value
    return None


def _as_name(value):
    """Return entity-link name when ShotGrid field is a link dict."""
    if isinstance(value, dict):
        return value.get("name") or value.get("code")
    return value
