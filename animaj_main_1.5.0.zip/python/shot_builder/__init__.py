"""
Pure bpy shot builder module.

No SGTK, no ShotGrid API. Receives all resolved data as plain Python arguments.
Called from both:
  - hooks/tk-multi-workfiles2/scene_operation_tk-blender.py (interactive, via timer)
  - scripts/build_shot_runner.py (headless Blender)
"""

import os
import bpy


# Flip to True to restrict the editorial reference search to validated
# (reviewed/approved) Blender publishes only. Defaults to False so any
# existing version is accepted.
VALIDATED_ONLY = False

EDITORIAL_TEMPLATE_NAME = "Animaj - Editorial"

# PublishedFileType.code values that we accept as Blender publishes.
# Different projects / tk-blender versions register the type under
# different display names — historically "Blender Project File", more
# recently "Blender Scene" with the new tk-blender for Blender 5.
BLENDER_PUBLISH_TYPES = ("Blender Scene", "Blender Project File")


def build_shot_from_context(ctx):
    """
    Build a shot .blend file from a ShotGrid context.

    Resolves the layout reference .blend from the context, extracts frame range and FPS,
    and builds the shot with all assets linked in the layout.

    :param ctx: SGTK context (must contain shot entity)
    """
    sequence_scene_path = get_layout_scene_from_context(ctx)
    if not sequence_scene_path:
        print("[shot_builder] ERROR: could not resolve layout scene from context")
        return

    build_shot(
        sequence_scene_path=sequence_scene_path,
        frame_start=ctx.entity.get("sg_cut_in") or 1,
        frame_end=ctx.entity.get("sg_cut_out") or 250,
        fps=ctx.project.get("sg_fps") or 24,
        asset_list=[],  # Keep all assets from the layout by default
        output_path=None,  # Don't save by default in interactive sessions
    )

def build_shot(
    sequence_scene_path,
    frame_start,
    frame_end,
    fps,
    asset_list,
    output_path = None
):
    """
    Build a shot .blend file from a layout reference and a list of asset publishes.

    :param sequence_scene_path: str | None  — layout .blend to open as base scene
    :param frame_start:         int         — scene frame start (sg_cut_in)
    :param frame_end:           int         — scene frame end (sg_cut_out)
    :param fps:                 int         — project FPS
    :param asset_list:         list[str]    — assets to keep in the shot
    :param output_path:         str | None  — where to save the resulting file
    """
    print(f"[shot_builder] sequence_scene_path: {sequence_scene_path}")
    print(f"[shot_builder] output_path:         {output_path}")
    print(f"[shot_builder] frame range:         {frame_start} – {frame_end} @ {fps}fps")
    print(f"[shot_builder] asset_list:          {asset_list}")

    # 1. Open layout reference or start from scratch
    if sequence_scene_path and os.path.exists(sequence_scene_path):
        print(f"[shot_builder] Opening layout reference: {sequence_scene_path}")
        bpy.ops.wm.open_mainfile(filepath=sequence_scene_path)
    else:
        if sequence_scene_path:
            print(f"[shot_builder] WARNING: layout reference not found: {sequence_scene_path}")
        print("[shot_builder] Starting from default scene")
        bpy.ops.wm.read_homefile(use_empty=True)

    # 2. Frame range and FPS
    apply_frame_range(frame_start, frame_end, fps)

    # 3. Remove assets from the layout that are not in asset_list
    # clean_unexpected_assets(asset_list)

    # 4. Save
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        bpy.ops.wm.save_as_mainfile(filepath=output_path)
        print(f"[shot_builder] Saved: {output_path}")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def get_layout_scene_from_context(ctx, validated_only=None):
    """
    Resolve the layout reference .blend from a sibling Editorial shot.

    An "Editorial shot" is a Shot whose ``task_template`` is
    ``Animaj - Editorial``. It is "valid" as a reference if it has at
    least one Blender publish on a Layout-step task.

    To avoid silently picking the wrong reference, exactly one of the
    following two scenarios must hold:

        1. exactly one valid Editorial shot in the same sequence, or
        2. zero valid Editorial shots in the same sequence AND exactly
           one valid Editorial shot elsewhere in the same episode.

    Anything else (zero matches in both tiers, or two or more matches
    in any single tier) is treated as an error and returns ``None``.

    :param ctx: SGTK context (must contain shot entity)
    :param validated_only: if not None, overrides the module-level
        ``VALIDATED_ONLY`` flag. When True, only Blender publishes whose
        ``sg_status_list`` is ``vwd`` (viewed) or ``apr`` (approved) are
        accepted.
    :return: str | None local publish path
    """
    try:
        import sgtk
    except Exception as exc:
        print(f"[shot_builder] ERROR: SGTK unavailable in this session: {exc}")
        return None

    if not ctx or not ctx.entity or ctx.entity.get("type") != "Shot":
        print("[shot_builder] ERROR: context is not a Shot context")
        return None

    engine = sgtk.platform.current_engine()
    if not engine:
        print("[shot_builder] ERROR: no active SGTK engine")
        return None

    if validated_only is None:
        validated_only = VALIDATED_ONLY

    sg = engine.shotgun
    shot_id = ctx.entity.get("id")

    current_shot = sg.find_one(
        "Shot",
        [["id", "is", shot_id]],
        ["code", "sg_sequence", "sg_episode"],
    )
    if not current_shot:
        print(f"[shot_builder] ERROR: Shot not found for id={shot_id}")
        return None

    sequence = current_shot.get("sg_sequence")
    episode = current_shot.get("sg_episode")

    if not sequence and not episode:
        print("[shot_builder] ERROR: current shot has no sequence or episode")
        return None

    base_filters = [
        ["task_template.TaskTemplate.code", "is", EDITORIAL_TEMPLATE_NAME],
        ["id", "is_not", shot_id],
    ]

    # Tier 1 — same sequence
    if sequence:
        seq_candidates = sg.find(
            "Shot",
            base_filters + [["sg_sequence", "is", sequence]],
            ["code", "id"],
        )
        valid = _valid_editorial_shots(sg, seq_candidates, validated_only)
        if len(valid) > 1:
            print(
                "[shot_builder] ERROR: ambiguous reference — "
                f"{len(valid)} Editorial shots with a Layout publish in the same sequence: "
                f"{[s.get('code') or s.get('id') for s, _ in valid]}"
            )
            return None
        if len(valid) == 1:
            return _log_resolved(valid[0], "same sequence")

    # Tier 2 — same episode, outside the current sequence
    if episode:
        ep_filters = base_filters + [["sg_episode", "is", episode]]
        if sequence:
            ep_filters.append(["sg_sequence", "is_not", sequence])
        ep_candidates = sg.find("Shot", ep_filters, ["code", "id"])
        valid = _valid_editorial_shots(sg, ep_candidates, validated_only)
        if len(valid) > 1:
            print(
                "[shot_builder] ERROR: ambiguous reference — "
                f"{len(valid)} Editorial shots with a Layout publish elsewhere in the episode: "
                f"{[s.get('code') or s.get('id') for s, _ in valid]}"
            )
            return None
        if len(valid) == 1:
            return _log_resolved(valid[0], "same episode")

    print(
        "[shot_builder] ERROR: no Editorial shot with a Layout publish found "
        "in the same sequence or elsewhere in the episode"
    )
    return None


def _valid_editorial_shots(sg, shots, validated_only):
    """Return ``[(shot, publish_path), ...]`` for shots that have a layout publish."""
    valid = []
    for shot in shots:
        path = _latest_layout_blender_publish(sg, shot, validated_only=validated_only)
        if path:
            valid.append((shot, path))
    return valid


def _log_resolved(valid_entry, tier_name):
    shot, path = valid_entry
    print(
        f"[shot_builder] Resolved editorial reference: "
        f"{shot.get('code') or shot.get('id')} ({tier_name})"
    )
    print(f"[shot_builder] Resolved layout scene: {path}")
    return path


def _latest_layout_blender_publish(sg, shot, validated_only=False):
    """Return the local path of the latest Blender publish on a Layout-step
    task of the given shot, or None.
    """
    filters = [
        ["entity", "is", shot],
        ["published_file_type.PublishedFileType.code", "in", list(BLENDER_PUBLISH_TYPES)],
    ]
    if validated_only:
        filters.append(["sg_status_list", "in", ["vwd", "apr"]])

    publishes = sg.find(
        "PublishedFile",
        filters,
        [
            "path",
            "version_number",
            "id",
            "code",
            "sg_status_list",
            "task.Task.step.Step.code",
            "task.Task.step.Step.short_name",
        ],
        order=[
            {"field_name": "version_number", "direction": "desc"},
            {"field_name": "id", "direction": "desc"},
        ],
    )

    for publish in publishes:
        step_code = (publish.get("task.Task.step.Step.code") or "").lower()
        step_short = (publish.get("task.Task.step.Step.short_name") or "").lower()
        if "layout" not in step_code and "layout" not in step_short:
            continue
        path = _extract_local_path(publish)
        if path:
            return path
    return None


def _extract_local_path(publish):
    """Extract a usable local path from a PublishedFile path dict."""
    path_data = publish.get("path") or {}
    # SG path dicts differ by platform/env; check all common keys.
    for key in (
        "local_path",
        "local_path_windows",
        "local_path_linux",
        "local_path_mac",
        "url",
        "name",
    ):
        value = path_data.get(key)
        if value:
            return value
    return None

def apply_frame_range(frame_start, frame_end, fps):
    scene = bpy.context.scene
    scene.frame_start = frame_start
    scene.frame_end = frame_end
    scene.frame_set(frame_start)
    scene.render.fps = fps
    print(f"[shot_builder] Frame range set: {frame_start} – {frame_end} @ {fps}fps")


def collect_safe_libraries(asset_names):
    """
    Return the set of bpy.data.libraries that are safe to keep:
      - libraries whose filepath contains one of the expected asset names
      - any library transitively loaded BY a safe library (via library.parent)

    Example: MeadowGrounds.blend pulls in Rocks.blend → Rocks is safe too.
    """
    expected_lower = {name.lower() for name in asset_names}

    # Root match: libraries whose path contains an expected asset name
    safe = set()
    for lib in bpy.data.libraries:
        path_parts = lib.filepath.replace("\\", "/").lower().split("/")
        if any(expected in part for expected in expected_lower for part in path_parts):
            safe.add(lib)

    # Transitively include everything pulled in by a safe library
    changed = True
    while changed:
        changed = False
        for lib in bpy.data.libraries:
            if lib not in safe and lib.parent in safe:
                safe.add(lib)
                changed = True

    return safe


def get_collection_source_library(col):
    """Return the source library for a collection (handles direct links and overrides)."""
    if col.library:
        return col.library
    if col.override_library and col.override_library.reference:
        return col.override_library.reference.library
    return None


def clean_unexpected_assets(asset_list):
    """
    Walk the entire scene collection hierarchy and unlink any linked or
    override collection whose source library is not covered by asset_list
    (directly or transitively).

    override_hierarchy_create() places overrides directly under scene.collection,
    not inside the CHAR / PROP / ENV masters, so we must walk from the root.
    Local collections (masters, camera rigs, etc.) are recursed into but never
    removed.

    :param asset_list: list[str] — asset names to keep, e.g. ["Maya", "MeadowGrounds"]
    """
    if not asset_list:
        print("[shot_builder] asset_list is empty — all linked assets will be removed")

    safe_libs = collect_safe_libraries(asset_list)
    print(f"[shot_builder] Safe libraries ({len(safe_libs)}):")
    for lib in safe_libs:
        print(f"[shot_builder]   {lib.filepath}")

    # Collect (parent, child) pairs to remove — don't mutate while walking
    to_remove = []

    def _walk(parent):
        for child in parent.children:
            lib = get_collection_source_library(child)
            is_linked = child.library is not None or child.override_library is not None

            if not is_linked:
                # Local collection (e.g. CHAR / PROP / ENV master) — recurse into it
                _walk(child)
                continue

            if lib is not None and lib in safe_libs:
                print(f"[shot_builder] Keeping  {child.name}")
                continue

            lib_label = lib.filepath if lib else "override/unresolved"
            print(f"[shot_builder] Removing {child.name}  (library: {lib_label})")
            to_remove.append((parent, child))

    _walk(bpy.context.scene.collection)

    for parent, child in to_remove:
        parent.children.unlink(child)

    if to_remove:
        # Purge orphaned data blocks left behind by the unlinks
        bpy.ops.outliner.orphans_purge(
            do_local_ids=True,
            do_linked_ids=True,
            do_recursive=True,
        )
        print("[shot_builder] Orphan purge complete")


def link_asset(path):
    """Link the top-level collection from a published .blend file."""
    if not os.path.exists(path):
        print(f"[shot_builder] WARNING: asset not found, skipping: {path}")
        return

    asset_name = os.path.splitext(os.path.basename(path))[0]
    print(f"[shot_builder] Linking asset: {asset_name} from {path}")

    with bpy.data.libraries.load(path, link=True) as (data_from, data_to):
        if not data_from.collections:
            print(f"[shot_builder] WARNING: no collections in {path}")
            return

        # Prefer a collection that matches the file name, otherwise take the first
        match = None
        for col in data_from.collections:
            if col.lower() == asset_name.lower():
                match = col
                break
        if not match:
            match = data_from.collections[0]
            print(f"[shot_builder] No exact name match — using first collection: {match}")

        data_to.collections = [match]

    for col in data_to.collections:
        if col and col.name not in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.link(col)
            print(f"[shot_builder] Linked collection: {col.name}")
