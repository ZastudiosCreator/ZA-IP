import os
import subprocess
import sys
from shotgun_api3 import Shotgun
import shutil


SG_URL = "https://animaj.shotgrid.autodesk.com/"
SG_SCRIPT_NAME = "for_blender"
SG_SCRIPT_KEY = "fede*fpqm8Kmudtugbxyooatf"

BLENDER_EXE = os.environ.get("BLENDER_EXE", r"C:\Program Files\Blender Foundation\Blender 4.3\blender.exe")

PROJECT_NAME = "MTB-DF"


def connect_sg():
    return Shotgun(SG_URL, script_name=SG_SCRIPT_NAME, api_key=SG_SCRIPT_KEY)

def get_shot_data(sg, shot_code):
    filters = [["code", "is", shot_code]]
    fields = [
        "code",
        "project",
        "sg_cut_in",
        "sg_cut_out",
        "assets",
    ]

    shot = sg.find_one("Shot", filters, fields)

    if not shot:
        raise Exception(f"Shot {shot_code} not found!")

    return shot


# -------------------------------
# BUILD BLENDER FILE
# -------------------------------

def build_blender_file(shot_data, work_path, fps, asset_publish_paths):

    print(asset_publish_paths)

    import json
    assets_json = json.dumps(asset_publish_paths)

    cut_in = shot_data.get("sg_cut_in")
    cut_out = shot_data.get("sg_cut_out")

    blender_script = f"""
    
import bpy
import os
import json

asset_paths = json.loads(r'''{assets_json}''')

# Set FPS
bpy.context.scene.render.fps = {fps}
bpy.context.scene.use_preview_range = False
bpy.context.scene.frame_start = {cut_in}
bpy.context.scene.frame_end = {cut_out}
bpy.context.scene.frame_set({cut_in})

def create_link(path):
    if not os.path.exists(path):
        print(f"Missing file: {{path}}")
        return

    with bpy.data.libraries.load(path, link=True) as (data_from, data_to):
        data_to.collections = data_from.collections

    for collection in data_to.collections:
        if collection:
            instance = bpy.data.objects.new(collection.name, None)
            instance.instance_type = "COLLECTION"
            instance.instance_collection = collection
            bpy.context.scene.collection.objects.link(instance)

# Link all assets
for path in asset_paths:
    create_link(path)

# Save file
bpy.ops.wm.save_as_mainfile(filepath=r"{work_path}")
"""
    import tempfile

    temp_dir = tempfile.gettempdir()
    temp_script = os.path.join(temp_dir, "temp_blender_build.py")

    with open(temp_script, "w") as f:
        f.write(blender_script)

    # Run Blender headless
    subprocess.run([
        BLENDER_EXE,
        "--background",
        "--python", temp_script
    ])

    os.remove(temp_script)

#     # Create temporary blender python script
#     blender_script = f"""
# import bpy
#
# # Set FPS
# bpy.context.scene.render.fps = {fps}
#
# # Clear preview range (important)
# bpy.context.scene.use_preview_range = False
#
# # Set Frame Range
# bpy.context.scene.frame_start = {cut_in}
# bpy.context.scene.frame_end = {cut_out}
#
# # Set current frame to cut in
# bpy.context.scene.frame_set({cut_in})
#
# # Store assets info in scene custom property
# bpy.context.scene["linked_assets"] = [a['name'] for a in {assets}]
#
# # Save file
# bpy.ops.wm.save_as_mainfile(filepath=r"{work_path}")
# """


def get_published_file_type(sg, type_name):
    return sg.find_one(
        "PublishedFileType",
        [["code", "is", type_name]],
        ["id", "code"]
    )

def get_publish_path(work_path):
    work_dir = os.path.dirname(work_path)
    publish_dir = work_dir.replace("work", "publish")

    filename = os.path.basename(work_path)
    publish_path = os.path.join(publish_dir, filename)

    return publish_path

# publish to shotgrid

def publish_file(sg, shot_data, work_path):
    shot_entity = {
        "type": "Shot",
        "id": shot_data["id"]
    }

    publish_type = get_published_file_type(sg, "Blender Scene")

    if not publish_type:
        raise Exception("PublishedFileType 'Blender Scene' not found in ShotGrid")

    sg.create("PublishedFile", {
        "project": shot_data["project"],
        "entity": shot_entity,
        "code": os.path.basename(work_path),
        "path": {"local_path": work_path},
        "published_file_type": publish_type  # <-- now includes ID
    })

def get_project_fps(sg, project_entity):
    project = sg.find_one(
        "Project",
        [["id", "is", project_entity["id"]]],
        ["sg_fps"]   # <-- your actual fps field name
    )

    if not project or not project.get("sg_fps"):
        raise Exception("Project FPS not found!")

    return project["sg_fps"]

def get_latest_asset_publish(sg, asset):
    """
    Returns latest published Blender Scene for an asset
    """
    filters = [
        ["entity", "is", asset],
        ["published_file_type.PublishedFileType.code", "is", "Blender Project File"],
    ]

    fields = [
        "path",
        "version_number",
        "created_at"
    ]

    publishes = sg.find(
        "PublishedFile",
        filters,
        fields,
        order=[{"field_name": "version_number", "direction": "desc"}]
    )

    if not publishes:
        return None

    return publishes[0]



def main(shot_code, work_path):
    sg = connect_sg()

    shot_data = get_shot_data(sg, shot_code)
    print(shot_data)

    print("Assets on shot:", shot_data.get("assets"))

    fps = get_project_fps(sg, shot_data["project"])
    print(fps)

    asset_publish_paths = []

    for asset in shot_data.get("assets", []):
        publish = get_latest_asset_publish(sg, asset)

        if publish and publish.get("path"):
            asset_publish_paths.append(
                publish["path"]["local_path"]
            )

    build_blender_file(shot_data, work_path, fps, asset_publish_paths)

    publish_path = get_publish_path(work_path)

    shutil.copy2(work_path, publish_path)

    publish_file(sg, shot_data, publish_path)

    print("Shot build complete.")



if __name__ == "__main__":
    shot_code = sys.argv[1]
    work_path = sys.argv[2]

    main(shot_code, work_path)
