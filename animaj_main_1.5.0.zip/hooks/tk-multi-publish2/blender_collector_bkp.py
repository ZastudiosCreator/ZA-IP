# blender_collector.py

import os
import bpy
import sgtk

HookBaseClass = sgtk.get_hook_baseclass()


class BlenderSessionCollector(HookBaseClass):
    """
    Collector that gathers the current Blender session and
    creates publish items for:
        - Blender Session (.blend)
        - Playblast (mp4)
    """

    @property
    def settings(self):
        """
        Collector settings from environment config
        """
        collector_settings = super().settings or {}

        collector_settings.update({
            "Work Template": {
                "type": "template",
                "default": None,
                "description": "Template path for artist work files."
            }
        })

        return collector_settings

    # ---------------------------------------------------------
    # PROCESS CURRENT SESSION
    # ---------------------------------------------------------

    def process_current_session(self, settings, parent_item):

        publisher = self.parent
        engine = publisher.engine
        context = engine.context

        # -----------------------------------------------------
        # ENSURE FILE IS SAVED
        # -----------------------------------------------------

        path = bpy.data.filepath

        if not path:
            self.logger.error("Please save the Blender file before publishing.")
            return

        path = os.path.normpath(path)

        # -----------------------------------------------------
        # CREATE SESSION ITEM
        # -----------------------------------------------------

        session_item = parent_item.create_item(
            "blender.session",
            "Blender Session",
            os.path.basename(path)
        )

        session_item.context = context
        session_item.properties["path"] = path
        session_item.properties["publish_type"] = "Blender Scene"

        self.logger.info(f"Collected Blender session: {path}")

        # -----------------------------------------------------
        # WORK TEMPLATE
        # -----------------------------------------------------

        work_template_setting = settings.get("Work Template")

        if work_template_setting and work_template_setting.value:

            work_template = publisher.get_template_by_name(
                work_template_setting.value
            )

            session_item.properties["work_template"] = work_template

            self.logger.info(f"Work template: {work_template}")
            self.logger.info(f"Session path: {path}")

            # -------------------------------------------------
            # EXTRACT FIELDS SAFELY
            # -------------------------------------------------

            if work_template.validate(path):

                fields = work_template.get_fields(path)
                session_item.properties["fields"] = fields

                self.logger.info(f"Template fields extracted: {fields}")

            else:
                self.logger.warning(
                    "Current file path does not match the configured work template. "
                    "Fields could not be extracted."
                )

        else:
            self.logger.warning("No Work Template configured for this collector.")

        return session_item