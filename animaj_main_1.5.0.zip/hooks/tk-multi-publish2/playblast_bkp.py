import os
import bpy
import sgtk
import shutil

import blf
import gpu
from gpu_extras.batch import batch_for_shader

HookBaseClass = sgtk.get_hook_baseclass()


class BlenderPlayblastPlugin(HookBaseClass):

    @property
    def name(self):
        return "Blender Playblast"

    @property
    def description(self):
        return "Generate Blender playblast and upload to ShotGrid"

    @property
    def item_filters(self):
        return ["blender.playblast"]

    # -----------------------------
    # ACCEPT
    # -----------------------------

    @property
    def settings(self):
        settings = super().settings or {}
        settings.update({
            "Work Playblast Template": {
                "type": "template",
                "default": None,
                "description": "Template for playblast work output."
            },
            "Publish Playblast Template": {
                "type": "template",
                "default": None,
                "description": "Template for playblast publish output."
            }
        })
        return settings

    def accept(self, settings, item):
        return {
            "accepted": True,
            "checked": True
        }

    def validate(self, settings, item):

        work_template = self.parent.get_template_by_name(
            settings["Work Playblast Template"].value
        )

        publish_template = self.parent.get_template_by_name(
            settings["Publish Playblast Template"].value
        )

        fields = item.parent.properties.get("fields")

        if not fields:
            raise Exception("Fields not found on session item.")

        item.properties["fields"] = fields
        item.properties["work_template"] = work_template
        item.properties["publish_template"] = publish_template

        return True

    def publish(self, settings, item):

        sg = self.parent.sgtk.shotgun
        context = item.context
        fields = item.properties["fields"]

        work_template = item.properties["work_template"]
        publish_template = item.properties["publish_template"]

        work_path = work_template.apply_fields(fields)
        publish_path = publish_template.apply_fields(fields)

        os.makedirs(os.path.dirname(work_path), exist_ok=True)
        os.makedirs(os.path.dirname(publish_path), exist_ok=True)

        # ----------------------------------
        # REAL PLAYBLAST → VIEWPORT
        # ----------------------------------

        try:
            # ----------------------------------
            # PLAYBLAST EXECUTION
            # ----------------------------------

            bpy.context.window_manager["sg_fields"] = fields

            self._playblast(work_path)

            if not os.path.exists(work_path):
                raise Exception("Playblast file was not created.")

            item.parent.properties["playblast_success"] = True

        except Exception as e:
            self.logger.error(f"Playblast failed: {e}")

            item.parent.properties["playblast_success"] = False
            raise Exception("Stopping publish because playblast failed.")

        shutil.copy2(work_path, publish_path)

        self.logger.info(f"Copied playblast → {publish_path}")

        # ----------------------------------
        # CREATE VERSION
        # ----------------------------------

        version_data = {
            "project": context.project,
            "code": os.path.basename(publish_path),
            "entity": context.entity,
            "sg_task": context.task,
            "description": "Auto playblast publish",
            "sg_path_to_movie": publish_path,
        }

        version = sg.create("Version", version_data)

        # link to published blend
        published_file = item.parent.properties.get("sg_publish_data")

        if published_file:
            sg.update(
                "Version",
                version["id"],
                {"published_files": [published_file]}
            )

            self.logger.info("Linked Version to PublishedFile.")
        else:
            self.logger.warning("No PublishedFile found to link.")

        # upload movie
        sg.upload(
            "Version",
            version["id"],
            publish_path,
            field_name="sg_uploaded_movie"
        )

        self.logger.info("Playblast uploaded to ShotGrid.")

    def finalize(self, settings, item):
        pass

    def _playblast(self, path):

        scene = bpy.context.scene

        scene.render.filepath = path
        scene.render.image_settings.file_format = 'FFMPEG'
        scene.render.ffmpeg.format = 'MPEG4'
        scene.render.ffmpeg.codec = 'H264'

        fields = bpy.context.window_manager.get("sg_fields", {})

        EPISODE = fields.get("Episode", "EP")
        SEQUENCE = fields.get("Sequence", "SEQ")
        SHOT = fields.get("Shot", "SHOT")

        self.logger.info(f"Episode: {EPISODE}, Sequence: {SEQUENCE}, Shot: {SHOT}")

        cam = scene.camera
        if not cam:
            raise Exception("No active camera in the scene")

        cam.data.show_safe_areas = True

        safe = scene.safe_areas
        safe.title = (0.9, 0.9)
        safe.action = (0.95, 0.95)

        # ------------------------------------------------------------------
        # GET VIEWPORT
        # ------------------------------------------------------------------

        window = bpy.context.window_manager.windows[0]
        screen = window.screen

        area = next(a for a in screen.areas if a.type == 'VIEW_3D')
        region = next(r for r in area.regions if r.type == 'WINDOW')
        space = area.spaces.active
        overlay = space.overlay

        overlay.show_overlays = True

        # ------------------------------------------------------------------
        # HUD TEXT
        # ------------------------------------------------------------------

        overlay.show_overlays = True
        overlay.show_text = True
        overlay.show_stats = False

        # ------------------------------------------------------------------
        # RENDER STAMP (SHOT INFO)
        # ------------------------------------------------------------------

        scene.render.use_stamp = True
        scene.render.stamp_font_size = 18
        scene.render.use_stamp_frame = True
        scene.render.use_stamp_camera = False
        scene.render.use_stamp_filename = True

        scene.render.stamp_note_text = f"{EPISODE}  {SEQUENCE}  {SHOT}"
        scene.render.use_stamp_note = True

        # ------------------------------------------------------------------
        # PLAYBLAST
        # ------------------------------------------------------------------

        with bpy.context.temp_override(window=window, area=area, region=region):
            # VERY IMPORTANT → go to camera view so safe areas appear
            space.region_3d.view_perspective = 'CAMERA'
            space.lock_camera = True

            bpy.ops.render.opengl(animation=True)




