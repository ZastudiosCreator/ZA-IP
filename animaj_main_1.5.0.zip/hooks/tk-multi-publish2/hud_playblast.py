import os
import bpy
import sgtk
import shutil
import blf
from bpy.types import SpaceView3D

HookBaseClass = sgtk.get_hook_baseclass()


class BlenderPlayblastPlugin(HookBaseClass):

    _draw_handle = None

    # -----------------------------
    # HUD BUILD
    # -----------------------------

    def _build_hud_strings_from_fields(self, fields, scene):
        ep  = fields.get("Episode", "EP")
        seq = fields.get("Sequence", "SEQ")
        sh  = fields.get("Shot", "SHOT")
        ver = fields.get("version", "v000")

        frame = scene.frame_current
        start = scene.frame_start
        end   = scene.frame_end

        left  = f"{ep}  {seq}  {sh}"
        mid   = f"{start}-{end} | {frame}"
        right = f"{ver}"

        return left, mid, right

    # -----------------------------
    # HUD DRAW
    # -----------------------------

    def _draw_hud_callback(self, context):
        font_id = 0
        blf.size(font_id, 18)

        blf.position(font_id, 40, 40, 0)
        blf.draw(font_id, self._hud_left)

        blf.position(font_id, 900, 40, 0)
        blf.draw(font_id, self._hud_mid)

        blf.position(font_id, 1700, 40, 0)
        blf.draw(font_id, self._hud_right)

    # -----------------------------
    # SAFE AREAS
    # -----------------------------

    def _enable_safe_areas(self):
        scene = bpy.context.scene

        scene.safe_areas.title = 0.8
        scene.safe_areas.action = 0.9

        for area in bpy.context.screen.areas:
            if area.type == "VIEW_3D":
                area.spaces.active.overlay.show_safe_areas = True

    # -----------------------------
    # VIEWPORT PLAYBLAST
    # -----------------------------

    def _viewport_playblast(self, output_path, fields):

        scene = bpy.context.scene

        # Build HUD text
        self._hud_left, self._hud_mid, self._hud_right = \
            self._build_hud_strings_from_fields(fields, scene)

        self._enable_safe_areas()

        # Register draw handler
        self._draw_handle = SpaceView3D.draw_handler_add(
            self._draw_hud_callback, (bpy.context,), "WINDOW", "POST_PIXEL"
        )

        scene.render.filepath = output_path
        scene.render.image_settings.file_format = "FFMPEG"
        scene.render.ffmpeg.format = "MPEG4"

        bpy.ops.render.opengl(animation=True, view_context=True)

        # Remove handler
        if self._draw_handle:
            SpaceView3D.draw_handler_remove(self._draw_handle, "WINDOW")
            self._draw_handle = None

    # -----------------------------
    # DESCRIPTION
    # -----------------------------

    @property
    def name(self):
        return "Blender Playblast"

    @property
    def description(self):
        return "Generate Blender playblast and upload to ShotGrid"

    @property
    def item_filters(self):
        return ["blender.playblast"]

    # -----------------------------
    # SETTINGS
    # -----------------------------

    @property
    def settings(self):
        settings = super().settings or {}
        settings.update({
            "Work Playblast Template": {
                "type": "template",
                "default": None,
            },
            "Publish Playblast Template": {
                "type": "template",
                "default": None,
            }
        })
        return settings

    def accept(self, settings, item):
        return {"accepted": True, "checked": True}

    def validate(self, settings, item):

        work_template = self.parent.get_template_by_name(
            settings["Work Playblast Template"].value
        )

        publish_template = self.parent.get_template_by_name(
            settings["Publish Playblast Template"].value
        )

        fields = item.parent.properties.get("fields")

        if not fields:
            raise Exception("Fields not found on session item.")

        item.properties["fields"] = fields
        item.properties["work_template"] = work_template
        item.properties["publish_template"] = publish_template

        return True

    # -----------------------------
    # PUBLISH
    # -----------------------------

    def publish(self, settings, item):

        sg = self.parent.sgtk.shotgun
        context = item.context
        fields = item.properties["fields"]

        work_template = item.properties["work_template"]
        publish_template = item.properties["publish_template"]

        work_path = work_template.apply_fields(fields)
        publish_path = publish_template.apply_fields(fields)

        os.makedirs(os.path.dirname(work_path), exist_ok=True)
        os.makedirs(os.path.dirname(publish_path), exist_ok=True)

        scene = bpy.context.scene

        scene.render.resolution_x = 720
        scene.render.resolution_y = 1080
        scene.render.fps = 25

        if scene.camera:
            scene.camera.hide_render = False

        # 🎬 PLAYBLAST WITH HUD
        self._viewport_playblast(work_path, fields)

        shutil.copy2(work_path, publish_path)

        self.logger.info(f"Copied playblast → {publish_path}")

        # -----------------------
        # CREATE VERSION
        # -----------------------

        version_data = {
            "project": context.project,
            "code": os.path.basename(publish_path),
            "entity": context.entity,
            "sg_task": context.task,
            "description": "Auto playblast publish",
        }

        version = sg.create("Version", version_data)

        published_file = item.parent.properties.get("sg_publish_data")

        if published_file:
            sg.update(
                "Version",
                version["id"],
                {"published_files": [published_file]}
            )

        sg.upload(
            "Version",
            version["id"],
            publish_path,
            field_name="sg_uploaded_movie"
        )

        self.logger.info("Playblast uploaded to ShotGrid.")

    def finalize(self, settings, item):
        pass
