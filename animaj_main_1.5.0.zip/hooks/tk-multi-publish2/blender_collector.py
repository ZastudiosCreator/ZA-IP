import os
import bpy
import sgtk

HookBaseClass = sgtk.get_hook_baseclass()


class BlenderSessionCollector(HookBaseClass):
    """
    Collector that gathers the current Blender session and
    creates publish items for:
        - Blender Session (.blend)
        - Playblast (mp4)
    """

    @property
    def settings(self):
        """
        Collector settings from environment config
        """
        collector_settings = super().settings or {}

        collector_settings.update({
            "Work Template": {
                "type": "template",
                "default": None,
                "description": "Template path for artist work files."
            }
        })

        return collector_settings

    # ---------------------------------------------------------
    # PROCESS CURRENT SESSION
    # ---------------------------------------------------------

    def process_current_session(self, settings, parent_item):

        publisher = self.parent
        engine = publisher.engine
        context = engine.context

        # -----------------------------------------------------
        # Ensure file is saved
        # -----------------------------------------------------

        path = bpy.data.filepath

        if not path:
            self.logger.error("Please save the Blender file before publishing.")
            return

        path = os.path.normpath(path)

        # -----------------------------------------------------
        # Create session item
        # -----------------------------------------------------

        session_item = parent_item.create_item(
            "blender.session",
            "Blender Session",
            os.path.basename(path)
        )

        session_item.properties["path"] = path
        session_item.properties["publish_type"] = "Blender Scene"
        session_item.context = context

        self.logger.info("Collected Blender session: {}".format(path))

        # -----------------------------------------------------
        # Attach work template
        # -----------------------------------------------------

        # Attach work template
        work_template_setting = settings.get("Work Template")

        if work_template_setting and work_template_setting.value:

            work_template = publisher.get_template_by_name(
                work_template_setting.value
            )

            session_item.properties["work_template"] = work_template

            path = bpy.data.filepath
            self.logger.info(f"DEBUG PATH: {path}")
            self.logger.info(f"DEBUG TEMPLATE: {work_template}")

            fields = work_template.get_fields(path)
            session_item.properties["fields"] = fields
            self.logger.info(f"FIELDS EXTRACTED: {fields}")

        # -----------------------------------------------------
        # CREATE PLAYBLAST ITEM
        # -----------------------------------------------------

        playblast_item = session_item.create_item(
            "blender.playblast",
            "Playblast",
            "Playblast MP4"
        )

        playblast_item.context = context
        playblast_item.properties["publish_type"] = "Playblast"

        # Attach playblast template
        playblast_template = publisher.get_template_by_name(
            "blender_shot_playblast"
        )

        if playblast_template:
            playblast_item.properties["playblast_template"] = playblast_template

        # Pass version fields to playblast item
        if "fields" in session_item.properties:
            playblast_item.properties["fields"] = session_item.properties["fields"]

        self.logger.info("Created Playblast item.")

        return session_item
