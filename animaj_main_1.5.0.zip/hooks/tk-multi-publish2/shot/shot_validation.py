import bpy
import sgtk
import os

HookBaseClass = sgtk.get_hook_baseclass()


class ShotValidationPlugin(HookBaseClass):

    @property
    def name(self):
        return "Shot Validation"

    @property
    def description(self):
        return "Validates shot before publish"

    @property
    def item_filters(self):
        return ["blender.session"]

    def accept(self, settings, item):
        return {"accepted": True, "checked": True}

    def validate(self, settings, item):
        scene = bpy.context.scene
        sg = self.parent.shotgun
        ctx = self.parent.context
        errors = []

        # --------------------------------------------------
        # 1. CONTEXT VALIDATION
        # --------------------------------------------------
        if ctx.entity["type"] != "Shot":
            errors.append("Not in a Shot context")

        path = bpy.data.filepath
        if ctx.entity["name"] not in path:
            errors.append("File name does not match Shot code")

        # --------------------------------------------------
        # 2. FPS VALIDATION
        # --------------------------------------------------
        if scene.render.fps != 25:
            errors.append(f"Scene FPS must be 25 (current: {scene.render.fps})")

        # --------------------------------------------------
        # 3. FRAME RANGE + KEYFRAME CLEANUP
        # --------------------------------------------------
        try:
            sg_data = sg.find_one(
                "Shot",
                [["id", "is", ctx.entity["id"]]],
                ["sg_cut_in", "sg_cut_out"]
            )
            if sg_data:
                sg_cut_in  = sg_data["sg_cut_in"]
                sg_cut_out = sg_data["sg_cut_out"]
                frame_start = scene.frame_start
                frame_end   = scene.frame_end

                # ── Frame range mismatch ──────────────────
                if frame_start != sg_cut_in or frame_end != sg_cut_out:

                    if ctx.step and ctx.step["name"].lower() == "layout":
                        user_confirmed = self._ask_frame_range_update(
                            frame_start, frame_end,
                            sg_cut_in, sg_cut_out
                        )

                        if user_confirmed:
                            sg.update(
                                "Shot",
                                ctx.entity["id"],
                                {
                                    "sg_cut_in": frame_start,
                                    "sg_cut_out": frame_end,
                                }
                            )
                            self.logger.info(
                                f"ShotGrid frame range updated: "
                                f"cut_in={frame_start}, cut_out={frame_end}"
                            )
                            cut_in = frame_start
                            cut_out = frame_end
                        else:
                            errors.append(
                                f"Frame range mismatch — "
                                f"Blender: {frame_start}–{frame_end}, "
                                f"ShotGrid: {sg_cut_in}–{sg_cut_out}"
                            )
                            cut_in = sg_cut_in
                            cut_out = sg_cut_out

                    else:
                        # Non-Layout steps — hard error, use ShotGrid values
                        errors.append(
                            f"Frame range mismatch — "
                            f"Blender: {frame_start}–{frame_end}, "
                            f"ShotGrid: {sg_cut_in}–{sg_cut_out}. "
                            f"Only the Layout step may update the ShotGrid cut range."
                        )
                        cut_in = sg_cut_in
                        cut_out = sg_cut_out

                else:
                    cut_in = frame_start
                    cut_out = frame_end

                # ── Keyframe cleanup ─────────────────────
                outside_keys = self._find_keys_outside_range(
                    scene, cut_in, cut_out
                )

                if outside_keys:
                    total = sum(len(v) for v in outside_keys.values())
                    user_confirmed = self._ask_delete_keyframes(
                        outside_keys, cut_in, cut_out, total
                    )

                    if user_confirmed:
                        deleted = self._delete_keyframes(outside_keys)
                        self.logger.info(
                            f"Deleted {deleted} keyframe(s) outside "
                            f"cut range {cut_in}–{cut_out}"
                        )
                    else:
                        errors.append(
                            f"{total} keyframe(s) found outside cut range "
                            f"({cut_in}–{cut_out}). Please remove them before publishing."
                        )

            else:
                errors.append("Could not find Shot data in ShotGrid")

        except Exception as e:
            self.logger.error(f"Keyframe validation failed: {e}")
            # Don't block publish on animation API issues — just skip keyframe cleanup
            pass

        # --------------------------------------------------
        # 4. CAMERA VALIDATION
        # --------------------------------------------------
        if not scene.camera:
            errors.append("No active camera")

        # --------------------------------------------------
        # 5. RIG VALIDATION
        # --------------------------------------------------
        armatures = [o for o in scene.objects if o.type == "ARMATURE"]
        if not armatures:
            errors.append("No character rigs found")

        # --------------------------------------------------
        # 6. ASSET LINKING VALIDATION
        # --------------------------------------------------
        local_armatures  = []
        linked_armatures = []
        broken_libraries = []

        for obj in bpy.data.objects:
            if obj.type != "ARMATURE":
                continue

            if obj.library:
                linked_armatures.append(obj)
                lib_path = bpy.path.abspath(obj.library.filepath)
                if not os.path.exists(lib_path):
                    broken_libraries.append(obj.name)

            elif obj.override_library:
                ref = obj.override_library.reference
                if ref and ref.library:
                    linked_armatures.append(obj)
                    lib_path = bpy.path.abspath(ref.library.filepath)
                    if not os.path.exists(lib_path):
                        broken_libraries.append(obj.name)
                else:
                    local_armatures.append(obj)
            else:
                local_armatures.append(obj)

        if local_armatures:
            errors.append(
                "Local rigs found (must be linked):\n  - "
                + "\n  - ".join(o.name for o in local_armatures)
            )

        if broken_libraries:
            errors.append(
                "Broken library links:\n  - "
                + "\n  - ".join(broken_libraries)
            )

        # --------------------------------------------------
        # DUPLICATE RIG CHECK
        # --------------------------------------------------
        linked_names = {o.name for o in linked_armatures}
        local_names  = {o.name for o in local_armatures}
        duplicates   = linked_names.intersection(local_names)

        if duplicates:
            errors.append(
                "Duplicate rigs (linked + local):\n  - "
                + "\n  - ".join(duplicates)
            )

        # --------------------------------------------------
        # 7. COLLECTION NAMING RULES
        # --------------------------------------------------
        allowed = {"CHAR", "PROP", "CAM", "ENV"}
        bad_collections = [
            c.name for c in scene.collection.children
            if c.name not in allowed
        ]
        if bad_collections:
            errors.append(
                "Unauthorized collections found:\n  - "
                + "\n  - ".join(bad_collections)
                + f"\n  Allowed collection names: {', '.join(sorted(allowed))}"
            )

        # --------------------------------------------------
        # RAISE ALL ERRORS AT ONCE
        # --------------------------------------------------
        if errors:
            header = f"{len(errors)} validation error(s) found:"
            full_message = header + "\n\n" + "\n\n".join(
                f"[{i + 1}] {err}" for i, err in enumerate(errors)
            )
            raise Exception(full_message)

        return True

    # --------------------------------------------------
    # HELPER — Iterate fcurves from action (Blender 5 compat)
    # --------------------------------------------------
    def _iter_fcurves(self, action):
        """
        Yields all fcurves from an action, handling both legacy
        (action.fcurves) and Blender 5+ layered animation structures.
        """
        # Try Blender 5+ layered structure
        if hasattr(action, "layers"):
            for layer in action.layers:
                if hasattr(layer, "strips"):
                    for strip in layer.strips:
                        if hasattr(strip, "channelbags"):
                            for channelbag in strip.channelbags:
                                if hasattr(channelbag, "fcurves"):
                                    for fcurve in channelbag.fcurves:
                                        yield fcurve
        # Fall back to legacy action.fcurves for older Blender versions
        elif hasattr(action, "fcurves"):
            for fcurve in action.fcurves:
                yield fcurve

    # --------------------------------------------------
    # HELPER — Find keyframes outside cut range
    # --------------------------------------------------
    def _find_keys_outside_range(self, scene, cut_in, cut_out):
        """
        Scans all objects in the scene for keyframes that fall
        outside [cut_in, cut_out].

        Returns a dict:  { obj_name: [frame, frame, ...] }
        Only objects with offending keys are included.
        """
        outside = {}

        for obj in scene.objects:
            if not obj.animation_data:
                continue
            action = obj.animation_data.action
            if not action:
                continue

            bad_frames = set()
            for fcurve in self._iter_fcurves(action):
                for kp in fcurve.keyframe_points:
                    frame = kp.co[0]
                    if frame < cut_in or frame > cut_out:
                        bad_frames.add(frame)

            if bad_frames:
                outside[obj.name] = sorted(bad_frames)

        return outside

    # --------------------------------------------------
    # HELPER — Delete collected keyframes
    # --------------------------------------------------
    def _delete_keyframes(self, outside_keys):
        """
        Deletes all keyframes in outside_keys from their
        respective object actions.

        Returns total number of keyframe points deleted.
        """
        deleted = 0

        for obj_name, frames in outside_keys.items():
            obj = bpy.data.objects.get(obj_name)
            if not obj or not obj.animation_data:
                continue
            action = obj.animation_data.action
            if not action:
                continue

            frame_set = set(frames)
            for fcurve in self._iter_fcurves(action):
                to_remove = [
                    kp for kp in fcurve.keyframe_points
                    if kp.co[0] in frame_set
                ]
                for kp in reversed(to_remove):
                    fcurve.keyframe_points.remove(kp)
                    deleted += 1

        return deleted

    # --------------------------------------------------
    # HELPER — Qt confirmation dialog for keyframe delete
    # --------------------------------------------------
    def _ask_delete_keyframes(self, outside_keys, cut_in, cut_out, total):
        """
        Shows a Qt dialog listing all objects that have keyframes
        outside the cut range, and asks the user to confirm deletion.

        Returns True  → user confirmed delete
                False → user cancelled
        """
        try:
            from PySide2 import QtWidgets, QtCore, QtGui
        except ImportError:
            from PySide6 import QtWidgets, QtCore, QtGui

        app = QtWidgets.QApplication.instance()
        if app is None:
            app = QtWidgets.QApplication([])

        dlg = QtWidgets.QDialog()
        dlg.setWindowTitle("Unwanted Keyframes Detected")
        dlg.setFixedWidth(480)
        dlg.setWindowFlags(
            dlg.windowFlags() | QtCore.Qt.WindowStaysOnTopHint
        )

        layout = QtWidgets.QVBoxLayout(dlg)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 16, 20, 16)

        # ── Title ─────────────────────────────────────────
        title = QtWidgets.QLabel("⚠  Keyframes Outside Cut Range Detected")
        title.setStyleSheet(
            "font-size: 13px; font-weight: bold; color: #c0392b;"
        )
        layout.addWidget(title)

        # ── Subtitle ──────────────────────────────────────
        subtitle = QtWidgets.QLabel(
            f"Found <b>{total}</b> keyframe(s) outside the cut range "
            f"<b>{cut_in} – {cut_out}</b> on the following objects:"
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("font-size: 11px; color: black;")
        layout.addWidget(subtitle)

        # ── Scrollable object/frame list ──────────────────
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(min(180, 36 + len(outside_keys) * 22))
        scroll.setStyleSheet("border: 1px solid #ccc;")

        inner = QtWidgets.QWidget()
        inner_layout = QtWidgets.QVBoxLayout(inner)
        inner_layout.setSpacing(2)
        inner_layout.setContentsMargins(8, 6, 8, 6)

        for obj_name, frames in outside_keys.items():
            frame_str = ", ".join(str(int(f)) for f in frames[:12])
            if len(frames) > 12:
                frame_str += f"  … (+{len(frames) - 12} more)"
            row_text = f"<b>{obj_name}</b>:  frames  {frame_str}"
            lbl = QtWidgets.QLabel(row_text)
            lbl.setStyleSheet("font-size: 10px; color: black;")
            lbl.setWordWrap(True)
            inner_layout.addWidget(lbl)

        inner_layout.addStretch()
        scroll.setWidget(inner)
        layout.addWidget(scroll)

        # ── Question ──────────────────────────────────────
        question = QtWidgets.QLabel(
            "Do you want to delete these keyframes before publishing?"
        )
        question.setWordWrap(True)
        question.setStyleSheet("font-size: 11px; font-style: italic;")
        layout.addWidget(question)

        # ── Buttons ───────────────────────────────────────
        btn_row = QtWidgets.QHBoxLayout()
        btn_row.setSpacing(10)

        yes_btn = QtWidgets.QPushButton("✔  Yes, Delete Keyframes")
        yes_btn.setStyleSheet("""
            QPushButton {
                background: #27ae60; color: white;
                border: none; border-radius: 4px;
                padding: 6px 14px; font-weight: bold; font-size: 11px;
            }
            QPushButton:hover { background: #219150; }
        """)
        yes_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        yes_btn.clicked.connect(dlg.accept)

        no_btn = QtWidgets.QPushButton("✘  Keep Keyframes")
        no_btn.setStyleSheet("""
            QPushButton {
                background: #e74c3c; color: white;
                border: none; border-radius: 4px;
                padding: 6px 14px; font-size: 11px;
            }
            QPushButton:hover { background: #c0392b; }
        """)
        no_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        no_btn.clicked.connect(dlg.reject)

        btn_row.addStretch()
        btn_row.addWidget(yes_btn)
        btn_row.addWidget(no_btn)
        layout.addLayout(btn_row)

        return dlg.exec_() == QtWidgets.QDialog.Accepted

    # --------------------------------------------------
    # HELPER — PySide2/PySide6 frame range dialog
    # --------------------------------------------------
    def _ask_frame_range_update(self, blender_in, blender_out, sg_in, sg_out):
        try:
            from PySide2 import QtWidgets, QtCore, QtGui
        except ImportError:
            from PySide6 import QtWidgets, QtCore, QtGui

        app = QtWidgets.QApplication.instance()
        if app is None:
            app = QtWidgets.QApplication([])

        dlg = QtWidgets.QDialog()
        dlg.setWindowTitle("Frame Range Mismatch")
        dlg.setFixedWidth(440)
        dlg.setWindowFlags(
            dlg.windowFlags() | QtCore.Qt.WindowStaysOnTopHint
        )

        layout = QtWidgets.QVBoxLayout(dlg)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 16, 20, 16)

        title = QtWidgets.QLabel("⚠  Incorrect Frame Range Detected")
        title.setStyleSheet("font-size: 13px; font-weight: bold; color: #c0392b;")
        layout.addWidget(title)

        subtitle = QtWidgets.QLabel(
            "The Blender timeline does not match the ShotGrid cut range."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("font-size: 11px; color: #555;")
        layout.addWidget(subtitle)

        table = QtWidgets.QTableWidget(2, 3)
        table.setHorizontalHeaderLabels(["", "Cut In", "Cut Out"])
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        table.setFocusPolicy(QtCore.Qt.NoFocus)
        table.setStyleSheet("""
            QTableWidget         { border: 1px solid #ccc; font-size: 11px;}
            QHeaderView::section { background: #e0e0e0; font-weight: bold;
                                   padding: 4px; border: none; color: black; }
        """)

        data = [
            ("Blender",  str(blender_in),  str(blender_out)),
            ("ShotGrid", str(sg_in),        str(sg_out)),
        ]
        for r, (label, cut_in, cut_out) in enumerate(data):
            for c, text in enumerate([label, cut_in, cut_out]):
                item = QtWidgets.QTableWidgetItem(text)
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                table.setItem(r, c, item)

        table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.Stretch
        )
        table.setFixedHeight(80)
        layout.addWidget(table)

        question = QtWidgets.QLabel(
            "Do you want to update ShotGrid with the Blender frame range?"
        )
        question.setWordWrap(True)
        question.setStyleSheet("font-size: 11px; font-style: italic;")
        layout.addWidget(question)

        btn_row = QtWidgets.QHBoxLayout()
        btn_row.setSpacing(10)

        yes_btn = QtWidgets.QPushButton("✔  Yes, Update ShotGrid")
        yes_btn.setStyleSheet("""
            QPushButton {
                background: #27ae60; color: white;
                border: none; border-radius: 4px;
                padding: 6px 14px; font-weight: bold; font-size: 11px;
            }
            QPushButton:hover { background: #219150; }
        """)
        yes_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        yes_btn.clicked.connect(dlg.accept)

        no_btn = QtWidgets.QPushButton("✘  Keep ShotGrid Values")
        no_btn.setStyleSheet("""
            QPushButton {
                background: #e74c3c; color: white;
                border: none; border-radius: 4px;
                padding: 6px 14px; font-size: 11px;
            }
            QPushButton:hover { background: #c0392b; }
        """)
        no_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        no_btn.clicked.connect(dlg.reject)

        btn_row.addStretch()
        btn_row.addWidget(yes_btn)
        btn_row.addWidget(no_btn)
        layout.addLayout(btn_row)

        return dlg.exec_() == QtWidgets.QDialog.Accepted

    def publish(self, settings, item):
        pass

    def finalize(self, settings, item):
        pass