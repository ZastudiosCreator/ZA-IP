import os
import bpy
import sgtk
import shutil

from mathutils import Matrix, Vector
from datetime import date

HookBaseClass = sgtk.get_hook_baseclass()


# =================================================
# COLOR UTILS
# =================================================
def srgb_to_linear(c):
    if c <= 0.04045:
        return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4


def color(r, g, b):
    return (srgb_to_linear(r), srgb_to_linear(g), srgb_to_linear(b), 1.0)


# =================================================
# SAFE AREA (mesh-based, parented to camera)
# =================================================
def create_safe_area(cam_obj, cam, scene, safe, name, rgba):
    frame_corners = cam.view_frame(scene=scene)
    center = sum(frame_corners, Vector()) / len(frame_corners)
    frame_corners = [center + (v - center) * safe for v in frame_corners]
    distance_offset = 0.001
    frame_corners = [v * (1 - distance_offset) for v in frame_corners]

    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(frame_corners, [], [(0, 1, 2, 3)])
    mesh.update()

    frame = bpy.data.objects.new(name, mesh)

    # ✅ Always link into CAM collection, fallback to scene root
    target_collection = (
        bpy.data.collections.get("CAM")
        or scene.collection
    )
    target_collection.objects.link(frame)

    frame.parent = cam_obj
    frame.matrix_parent_inverse = Matrix.Identity(4)

    wf = frame.modifiers.new("Wireframe", "WIREFRAME")
    wf.thickness = 0.01
    wf.use_relative_offset = False

    mat = bpy.data.materials.new(name + "_MAT")
    mat.use_nodes = True
    mat.blend_method = 'OPAQUE'
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    em = nodes.new("ShaderNodeEmission")
    out = nodes.new("ShaderNodeOutputMaterial")
    em.inputs[0].default_value = rgba
    em.inputs[1].default_value = 1.0
    links.new(em.outputs[0], out.inputs[0])
    frame.data.materials.append(mat)
    frame.show_in_front = True


class BlenderPlayblastPlugin(HookBaseClass):

    @property
    def name(self):
        return "Blender Playblast"

    @property
    def description(self):
        return "Generate Blender playblast, links to the blender file and upload to ShotGrid"

    @property
    def item_filters(self):
        return ["blender.playblast"]

    @property
    def settings(self):
        settings = super().settings or {}
        settings.update({
            "Work Playblast Template": {
                "type": "template",
                "default": None,
                "description": "Template for playblast work output."
            },
            "Publish Playblast Template": {
                "type": "template",
                "default": None,
                "description": "Template for playblast publish output."
            }
        })
        return settings

    def accept(self, settings, item):
        return {"accepted": True, "checked": True}

    def validate(self, settings, item):
        work_template = self.parent.get_template_by_name(
            settings["Work Playblast Template"].value
        )
        publish_template = self.parent.get_template_by_name(
            settings["Publish Playblast Template"].value
        )
        fields = item.parent.properties.get("fields")
        if not fields:
            raise Exception("Fields not found on session item.")

        item.properties["fields"] = fields
        item.properties["work_template"] = work_template
        item.properties["publish_template"] = publish_template
        return True

    def publish(self, settings, item):
        sg = self.parent.sgtk.shotgun
        context = item.context
        fields = item.properties["fields"]

        work_template = item.properties["work_template"]
        publish_template = item.properties["publish_template"]

        work_path = work_template.apply_fields(fields)
        publish_path = publish_template.apply_fields(fields)

        os.makedirs(os.path.dirname(work_path), exist_ok=True)
        os.makedirs(os.path.dirname(publish_path), exist_ok=True)

        created_version_id = None
        publish_path_copied = False

        try:
            bpy.context.window_manager["sg_fields"] = fields
            self._playblast(work_path)

            if not os.path.exists(work_path):
                raise Exception("Playblast file was not created.")

            item.parent.properties["playblast_success"] = True

            shutil.copy2(work_path, publish_path)
            publish_path_copied = True
            self.logger.info(f"Copied playblast → {publish_path}")

            version_data = {
                "project": context.project,
                "code": os.path.basename(publish_path),
                "entity": context.entity,
                "sg_task": context.task,
                "description": "Auto playblast publish",
                "sg_path_to_movie": publish_path,
            }
            version = sg.create("Version", version_data)
            created_version_id = version["id"]

            published_file = item.parent.properties.get("sg_publish_data")
            if published_file:
                sg.update("Version", version["id"], {"published_files": [published_file]})
                self.logger.info("Linked Version to PublishedFile.")
            else:
                self.logger.warning("No PublishedFile found to link.")

            sg.upload("Version", version["id"], publish_path, field_name="sg_uploaded_movie")
            self.logger.info("Playblast uploaded to ShotGrid.")

        except Exception as e:
            self.logger.error(f"Playblast publish failed: {e}")
            item.parent.properties["playblast_success"] = False
            self._rollback(
                item,
                publish_path=publish_path if publish_path_copied else None,
                version_id=created_version_id,
            )
            raise Exception(f"Stopping publish because playblast failed: {e}")

    def _rollback(self, item, publish_path=None, version_id=None):
        """Best-effort revert so the publish chain can be re-run cleanly.

        Removes (in order, each step independently):
          - the playblast Version on SG (if this plugin created one),
          - the parent PublishedFile (the .blend) and its on-disk file,
          - the publish-side playblast .mp4 (if it was already copied).

        Errors are logged but never re-raised — the caller is already in
        an exception path and we want every step attempted.
        """
        sg = self.parent.sgtk.shotgun

        if version_id:
            try:
                sg.delete("Version", version_id)
                self.logger.info(f"Rollback: deleted Version id={version_id}")
            except Exception as e:
                self.logger.error(
                    f"Rollback: could not delete Version id={version_id}: {e}"
                )

        published_file = item.parent.properties.get("sg_publish_data")
        if published_file:
            local_path = (published_file.get("path") or {}).get("local_path")
            if local_path and os.path.exists(local_path):
                try:
                    os.remove(local_path)
                    self.logger.info(f"Rollback: deleted file {local_path}")
                except Exception as e:
                    self.logger.error(
                        f"Rollback: could not delete file {local_path}: {e}"
                    )

            pf_id = published_file.get("id")
            if pf_id:
                try:
                    sg.delete("PublishedFile", pf_id)
                    self.logger.info(f"Rollback: deleted PublishedFile id={pf_id}")
                except Exception as e:
                    self.logger.error(
                        f"Rollback: could not delete PublishedFile id={pf_id}: {e}"
                    )

            item.parent.properties["sg_publish_data"] = None

        if publish_path and os.path.exists(publish_path):
            try:
                os.remove(publish_path)
                self.logger.info(f"Rollback: deleted file {publish_path}")
            except Exception as e:
                self.logger.error(
                    f"Rollback: could not delete file {publish_path}: {e}"
                )

    def finalize(self, settings, item):
        pass

    def _playblast(self, path):


        scene = bpy.context.scene
        cam_obj = scene.camera

        scene.render.use_simplify = False

        if not cam_obj:
            raise Exception("No active camera")

        if not bpy.data.filepath:
            raise Exception("Save the Blender file before running playblast.")

        # --------------------------------------------------
        # CLEAN UP any old safe area children first
        # --------------------------------------------------
        for c in list(cam_obj.children):
            bpy.data.objects.remove(c, do_unlink=True)

        # --------------------------------------------------
        # CREATE MESH-BASED SAFE AREAS (from standalone script)
        # --------------------------------------------------
        create_safe_area(cam_obj, cam_obj.data, scene,
                         safe=0.9,
                         name="ACTION_SAFE",
                         rgba=color(1.0, 0.4, 0.0)  # orange
                         )
        create_safe_area(cam_obj, cam_obj.data, scene,
                         safe=0.8,
                         name="TITLE_SAFE",
                         rgba=color(1.0, 1.0, 0.0)  # yellow
                         )

        # --------------------------------------------------
                # VIEWPORT SETUP — do this FIRST before anything else
        # --------------------------------------------------
        window = bpy.context.window_manager.windows[0]
        screen = window.screen
        area = next(a for a in screen.areas if a.type == 'VIEW_3D')
        region = next(r for r in area.regions if r.type == 'WINDOW')
        space = area.spaces.active

        space.shading.type = 'MATERIAL'
        space.overlay.show_overlays = False
        space.region_3d.view_perspective = 'CAMERA'
        space.lock_camera = True

        # --------------------------------------------------
        # FORCE VIEWPORT REDRAW — let Blender settle
        # --------------------------------------------------
        try:
            with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=5)
        except Exception:
            # Fallback — tag area for redraw manually
            area.tag_redraw()
            bpy.context.view_layer.update() # 👈 forces redraw before render

        # --------------------------------------------------                                                      
        # STAMP / METADATA
        # --------------------------------------------------
        fields = bpy.context.window_manager.get("sg_fields", {})
        EPISODE = fields.get("Episode", "EP")
        SEQUENCE = fields.get("Sequence", "SEQ")
        SHOT = fields.get("Shot", "SHOT")
        DATE = date.today().strftime("%Y-%m-%d")

        scene.render.use_stamp = True
        scene.render.stamp_font_size = 24
        scene.render.stamp_foreground = (1.0, 1.0, 1.0, 1.0)
        scene.render.stamp_background = (0.0, 0.0, 0.0, 0.5)
        scene.render.use_stamp_note = True
        scene.render.stamp_note_text = f"{EPISODE} {SEQUENCE} {SHOT}    |    {DATE}"
        scene.render.use_stamp_frame = True
        scene.render.use_stamp_frame_range = True
        scene.render.use_stamp_scene = True
        scene.render.use_stamp_filename = False
        scene.render.use_stamp_date = False
        scene.render.use_stamp_time = False
        scene.render.use_stamp_render_time = False
        scene.render.use_stamp_camera = False
        scene.render.use_stamp_lens = False
        scene.render.use_stamp_marker = False
        scene.render.use_stamp_sequencer_strip = False
        scene.render.use_stamp_memory = False
        scene.render.use_stamp_hostname = False

        # Temporarily rename scene so stamp shows the shot name
        original_scene_name = scene.name
        scene.name = os.path.splitext(os.path.basename(path))[0]

        # --------------------------------------------------
        # OUTPUT SETTINGS
        # --------------------------------------------------
        scene.render.filepath = path
        # Blender 5 split image_settings: media_type must be VIDEO before
        # FFMPEG appears as a valid file_format. The attribute does not
        # exist on older Blender versions, hence the hasattr guard.
        if hasattr(scene.render.image_settings, "media_type"):
            scene.render.image_settings.media_type = 'VIDEO'
        scene.render.image_settings.file_format = 'FFMPEG'
        scene.render.ffmpeg.format = 'MPEG4'
        scene.render.ffmpeg.codec = 'H264'
        scene.render.ffmpeg.constant_rate_factor = 'HIGH'

        # --------------------------------------------------                                                  
        # RENDER PLAYBLAST
        # --------------------------------------------------
        with bpy.context.temp_override(window=window, area=area, region=region):
            bpy.ops.render.opengl(animation=True)

        # --------------------------------------------------
        # RESTORE
        # --------------------------------------------------
        scene.name = original_scene_name
        space.overlay.show_overlays = True
        for c in list(cam_obj.children):
            bpy.data.objects.remove(c, do_unlink=True)

        self.logger.info(f"✅ Playblast saved: {path}")