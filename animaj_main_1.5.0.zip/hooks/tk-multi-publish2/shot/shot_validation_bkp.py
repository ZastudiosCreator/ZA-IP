import bpy
import sgtk
import os

HookBaseClass = sgtk.get_hook_baseclass()


class ShotValidationPlugin(HookBaseClass):

    @property
    def name(self):
        return "Shot Validation"

    @property
    def description(self):
        return "Validates shot before publish"

    @property
    def item_filters(self):
        return ["blender.session"]

    def accept(self, settings, item):
        return {"accepted": True, "checked": True}

    def validate(self, settings, item):
        scene = bpy.context.scene
        sg = self.parent.shotgun
        ctx = self.parent.context
        errors = []

        # --------------------------------------------------
        # 1. CONTEXT VALIDATION
        # --------------------------------------------------
        if ctx.entity["type"] != "Shot":
            errors.append("Not in a Shot context")

        path = bpy.data.filepath
        if ctx.entity["name"] not in path:
            errors.append("File name does not match Shot code")

        # --------------------------------------------------
        # 2. FPS VALIDATION
        # --------------------------------------------------
        if scene.render.fps != 25:
            errors.append(f"Scene FPS must be 25 (current: {scene.render.fps})")

        # --------------------------------------------------
        # 3. FRAME RANGE
        # --------------------------------------------------
        try:
            sg_data = sg.find_one(
                "Shot",
                [["id", "is", ctx.entity["id"]]],
                ["sg_cut_in", "sg_cut_out"]
            )
            if sg_data:
                if scene.frame_start != sg_data["sg_cut_in"]:
                    errors.append(
                        f"Start frame mismatch — scene: {scene.frame_start}, "
                        f"ShotGrid: {sg_data['sg_cut_in']}"
                    )
                if scene.frame_end != sg_data["sg_cut_out"]:
                    errors.append(
                        f"End frame mismatch — scene: {scene.frame_end}, "
                        f"ShotGrid: {sg_data['sg_cut_out']}"
                    )
            else:
                errors.append("Could not find Shot data in ShotGrid")
        except Exception as e:
            errors.append(f"ShotGrid query failed: {e}")

        # --------------------------------------------------
        # 4. CAMERA VALIDATION
        # --------------------------------------------------
        if not scene.camera:
            errors.append("No active camera")

        # --------------------------------------------------
        # 5. RIG VALIDATION
        # --------------------------------------------------
        armatures = [o for o in scene.objects if o.type == "ARMATURE"]
        if not armatures:
            errors.append("No character rigs found")

        # --------------------------------------------------
        # 6. ASSET LINKING VALIDATION
        # --------------------------------------------------
        local_armatures = []
        linked_armatures = []
        broken_libraries = []

        for obj in bpy.data.objects:
            if obj.type != "ARMATURE":
                continue

            if obj.library:
                linked_armatures.append(obj)
                lib_path = bpy.path.abspath(obj.library.filepath)
                if not os.path.exists(lib_path):
                    broken_libraries.append(obj.name)

            elif obj.override_library:
                ref = obj.override_library.reference
                if ref and ref.library:
                    linked_armatures.append(obj)
                    lib_path = bpy.path.abspath(ref.library.filepath)
                    if not os.path.exists(lib_path):
                        broken_libraries.append(obj.name)
                else:
                    local_armatures.append(obj)

            else:
                local_armatures.append(obj)

        if local_armatures:
            errors.append(
                "Local rigs found (must be linked):\n  - "
                + "\n  - ".join(o.name for o in local_armatures)
            )

        if broken_libraries:
            errors.append(
                "Broken library links:\n  - "
                + "\n  - ".join(broken_libraries)
            )

        # --------------------------------------------------
        # DUPLICATE RIG CHECK
        # --------------------------------------------------
        linked_names = {o.name for o in linked_armatures}
        local_names = {o.name for o in local_armatures}
        duplicates = linked_names.intersection(local_names)

        if duplicates:
            errors.append(
                "Duplicate rigs (linked + local):\n  - "
                + "\n  - ".join(duplicates)
            )

        # --------------------------------------------------
        # 7. COLLECTION NAMING RULES
        # --------------------------------------------------
        allowed = {"CHAR", "PROP", "CAM", "ENV"}
        bad_collections = [
            c.name for c in scene.collection.children
            if c.name not in allowed
        ]
        if bad_collections:
            errors.append(
                "Unauthorized collections found:\n  - "
                + "\n  - ".join(bad_collections)
                + f"\n  Allowed collection names: {', '.join(sorted(allowed))}"
            )

        # --------------------------------------------------
        # RAISE ALL ERRORS AT ONCE
        # --------------------------------------------------
        if errors:
            header = f"{len(errors)} validation error(s) found:"
            full_message = header + "\n\n" + "\n\n".join(
                f"[{i + 1}] {err}" for i, err in enumerate(errors)
            )
            raise Exception(full_message)

        return True

    def publish(self, settings, item):
        pass

    def finalize(self, settings, item):
        pass


