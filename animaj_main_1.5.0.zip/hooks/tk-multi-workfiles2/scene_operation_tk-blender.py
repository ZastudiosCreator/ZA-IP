# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####



import bpy
import os
import sys
import sgtk

# Module-load marker — prints once per fresh import so we can confirm which
# copy of this hook the running engine is actually loading.
print(f"[scene_operation_tk-blender] HOOK MODULE LOADED FROM: {__file__}")

HookClass = sgtk.get_hook_baseclass()

# Layout builder tools for camera backgrounds
layout_builder = None

class SceneOperation(HookClass):
    """
    Hook called to perform an operation with the
    current scene
    """

    def execute(
        self,
        operation,
        file_path,
        context,
        parent_action,
        file_version,
        read_only,
        **kwargs
    ):
        """
        Main hook entry point

        :param operation:       String
                                Scene operation to perform

        :param file_path:       String
                                File path to use if the operation
                                requires it (e.g. open)

        :param context:         Context
                                The context the file operation is being
                                performed in.

        :param parent_action:   This is the action that this scene operation is
                                being executed for.  This can be one of:
                                - open_file
                                - new_file
                                - save_file_as
                                - version_up

        :param file_version:    The version/revision of the file to be opened.  If this is 'None'
                                then the latest version should be opened.

        :param read_only:       Specifies if the file should be opened read-only or not

        :returns:               Depends on operation:
                                'current_path' - Return the current scene
                                                 file path as a String
                                'reset'        - True if scene was reset to an empty
                                                 state, otherwise False
                                all others     - None
        """

        self.logger.info(
            f"execute() → operation={operation!r} parent_action={parent_action!r} "
            f"file_path={file_path!r} context={context}"
        )

        if operation == "current_path":
            return bpy.data.filepath

        elif operation == "open":
            bpy.ops.wm.open_mainfile(filepath=file_path)

            # run after file loads
            bpy.app.timers.register(
                lambda: self._post_open(context), first_interval=0.2
            )

        elif operation == "save":
            bpy.ops.wm.save_mainfile("EXEC_AREA")

        elif operation == "save_as":
            bpy.ops.wm.save_mainfile(filepath=file_path)

        elif operation == "reset":

            self.logger.info(f"RESET branch entered (parent_action={parent_action!r})")

            if bpy.data.is_dirty:

                from sgtk.platform.qt import QtGui, QtCore

                res = QtGui.QMessageBox.question(
                    None,
                    "Save your scene?",
                    "Your scene has unsaved changes. Save before proceeding?",
                    QtGui.QMessageBox.Yes
                    | QtGui.QMessageBox.No
                    | QtGui.QMessageBox.Cancel,
                )

                if res == QtGui.QMessageBox.Cancel:
                    return False
                elif res == QtGui.QMessageBox.Yes:
                    scene_name = bpy.data.filepath
                    if not scene_name:
                        bpy.ops.wm.save_mainfile("INVOKE_AREA")
                    else:
                        bpy.ops.wm.save_mainfile(filepath=scene_name)

            bpy.ops.wm.read_homefile()

            self.logger.info("RESET → scheduled _post_reset timer (0.2s)")
            bpy.app.timers.register(
                lambda: self._post_reset(context), first_interval=0.2
            )

            return True

    def _import_config_module(self, module_name):
        config_python = os.path.normpath(
            os.path.join(self.disk_location, "..", "..", "python")
        )
        if config_python not in sys.path:
            sys.path.insert(0, config_python)
        import importlib
        return importlib.import_module(module_name)

    def _shot_uses_animaj_template(self, ctx):
        if not ctx.entity or ctx.entity["type"] != "Shot":
            return False
        engine = sgtk.platform.current_engine()
        shot = engine.shotgun.find_one(
            "Shot",
            [["id", "is", ctx.entity["id"]]],
            ["task_template"],
        )
        tmpl = (shot or {}).get("task_template") or {}
        return tmpl.get("id") == 31 or tmpl.get("name") == "Animaj - Shot"

    def _shot_uses_editorial_template(self, ctx):
        """Check if shot uses 'Animaj - Editorial' task template (case-insensitive)."""
        if not ctx.entity or ctx.entity["type"] != "Shot":
            return False
        engine = sgtk.platform.current_engine()
        shot = engine.shotgun.find_one(
            "Shot",
            [["id", "is", ctx.entity["id"]]],
            ["task_template"],
        )
        tmpl = (shot or {}).get("task_template") or {}
        tmpl_name = (tmpl.get("name") or "").strip().lower()
        self.logger.info(f"Shot task_template: {tmpl.get('name')!r} → normalized {tmpl_name!r}")
        return tmpl_name == "animaj - editorial"

    def _post_reset(self, ctx):
        self.logger.info(f"_post_reset fired (ctx={ctx})")
        if self._shot_uses_animaj_template(ctx):
            shot_builder = self._import_config_module("shot_builder")
            shot_builder.build_shot_from_context(ctx)
        self._post_open(ctx)
        return None

    def _post_open(self, ctx):
        self.logger.info(
            f"_post_open fired (entity={ctx.entity!r} step={ctx.step!r})"
        )

        if not ctx.entity or ctx.entity["type"] != "Shot":
            self.logger.info("_post_open → not a Shot context, bailing")
            return None

        step = ctx.step["name"].lower() if ctx.step else ""
        self.logger.info(f"_post_open → resolved step={step!r}")

        if step not in ["layout", "animation"]:
            self.logger.info(f"_post_open → step {step!r} is not layout/animation, bailing")
            return None

        self._process_shot(ctx)

        return None  # required for timer

    def _process_shot(self, ctx):
        self.logger.info(f"_process_shot started (hook __file__={__file__})")

        sg = self.parent.shotgun

        shot = sg.find_one(
            "Shot",
            [["id", "is", ctx.entity["id"]]],
            [
                "sg_cut_in",
                "sg_cut_out",
                "assets",
                "assets.Asset.sg_asset_type",
            ],
        )

        if not shot:
            return

        self._apply_frame_range(shot, ctx)
        self._setup_simplify()
        self._remove_default_objects()
        self._remove_default_collections()
        self._setup_default_asset_libraries()

        # if ctx.step and ctx.step["name"].lower() == "animation":

        # layout only builds assets
        if ctx.step and ctx.step["name"].lower() == "layout":

            # Editorial-template shots get a shot_cam with the latest
            # animatic/storyboard playblast as a MOVIE_CLIP background.
            uses_editorial = self._shot_uses_editorial_template(ctx)
            self.logger.info(f"Editorial template check: {uses_editorial}")
            if uses_editorial:
                layout_builder = self._import_config_module("layout_builder")
                layout_builder.build_layout_from_context(ctx)

            assets = shot.get("assets", [])

            self.logger.info("========= FULL RAW ASSET DATA =========")
            for i, a in enumerate(assets):
                self.logger.info(f"{i}: {a}")
            self.logger.info("=======================================")

            for asset in shot.get("assets", []):

                latest = self._get_latest_asset_publish(asset)
                self.logger.info(f"latest {latest}")

                if latest:
                    asset_type = self._get_asset_type(asset)
                    self.logger.info(f"asset_type {asset_type}")
                    self._link_collection(latest, asset["name"], asset_type)

    def _setup_default_asset_libraries(self):

        engine = sgtk.platform.current_engine()
        root = engine.sgtk.roots["primary"].replace("\\", "/")
        libraries = [
            ("Animation Library", f"{root}/mtb/work/library/animation_library"),
            ("Pose Library", f"{root}/mtb/work/library/pose_library"),
        ]

        prefs = bpy.context.preferences.filepaths

        for lib_name, lib_path in libraries:

            # 1️⃣ create folder if missing
            os.makedirs(lib_path, exist_ok=True)

            # 2️⃣ check if already registered
            exists = False
            for lib in prefs.asset_libraries:
                if os.path.normpath(lib.path) == os.path.normpath(lib_path):
                    exists = True
                    break

            # 3️⃣ create if not exists
            if not exists:
                new_lib = prefs.asset_libraries.new(name=lib_name)
                new_lib.path = lib_path
                self.logger.info(f"Created asset library: {lib_name}")

    def _get_asset_type(self, asset):

        sg = self.parent.shotgun

        data = sg.find_one(
            "Asset",
            [["id", "is", asset["id"]]],
            ["sg_asset_type"]
        )

        if data and data.get("sg_asset_type"):
            return data["sg_asset_type"]

        return None


    def _get_latest_asset_publish(self, asset):

        sg = self.parent.shotgun

        data = sg.find(
            "PublishedFile",
            [["entity", "is", asset]],
            ["path", "version_number"],
            order=[{"field_name": "version_number", "direction": "desc"}],
            limit=1,
        )

        if not data:
            self.logger.warning(f"No publish found for {asset['name']}")
            return None

        path_data = data[0].get("path")

        if not path_data:
            self.logger.warning(f"Publish has no path for {asset['name']}")
            return None

        if data:
            return data[0]["path"]["local_path"]

        return None

    def _remove_default_objects(self):

        default_names = {"Cube", "Light", "Camera"}
        scene_root = bpy.context.scene.collection

        for obj in list(scene_root.objects):
            if obj.name in default_names:
                bpy.data.objects.remove(obj, do_unlink=True)
                self.logger.info(f"Removed default object: {obj.name}")


    def _setup_layout_background(self, shot, ctx):
        """
        Setup camera background image with playblast for layout task.
        Looks for published playblast files for the shot.
        """
        global layout_builder
        
        if not layout_builder:
            try:
                layout_builder = self._import_config_module("layout_builder.camera_background")
                self.logger.info("Layout builder module loaded")
            except Exception as e:
                self.logger.warning(f"Failed to load layout_builder: {e}")
                return
        
        try:
            sg = self.parent.shotgun
            
            # Find playblast publishes for this shot
            playblasts = sg.find(
                "PublishedFile",
                [
                    ["entity", "is", ctx.entity],
                    ["published_file_type", "name_contains", "playblast"],
                ],
                ["path", "version_number"],
                order=[{"field_name": "version_number", "direction": "desc"}],
                limit=1,
            )
            
            if not playblasts:
                self.logger.info("No playblast found for layout background")
                return
            
            playblast_path = playblasts[0].get("path", {}).get("local_path")
            
            if not playblast_path or not os.path.exists(playblast_path):
                self.logger.warning(f"Playblast path not accessible: {playblast_path}")
                return
            
            directory = os.path.dirname(playblast_path)
            filename = os.path.basename(playblast_path)
            
            # Enable camera background
            layout_builder.enable_camera_background_images()
            layout_builder.add_background_image()
            
            # Setup with movie clip
            layout_builder.open_background_movie(playblast_path, directory)
            layout_builder.set_background_source_to_movie_clip()
            layout_builder.open_movie_clip(playblast_path, directory)
            layout_builder.set_background_display_depth('BACK')
            
            self.logger.info(f"Layout background setup complete: {filename}")
            
        except Exception as e:
            self.logger.warning(f"Error setting up layout background: {e}")

    def _apply_frame_range(self, shot, ctx):

        scene = bpy.context.scene

        cut_in = shot.get("sg_cut_in")
        cut_out = shot.get("sg_cut_out")

        if cut_in and cut_out:
            scene.frame_start = cut_in
            scene.frame_end = cut_out
            scene.frame_set(cut_in)

        project = self.parent.shotgun.find_one(
            "Project",
            [["id", "is", ctx.project["id"]]],
            ["sg_fps"],
        )

        if project and project.get("sg_fps"):
            scene.render.fps = int(project["sg_fps"])
            self.logger.info(f"FPS set from Project → {project['sg_fps']}")

        self.logger.info(
            f"Frame range applied → {cut_in} to {cut_out}"
        )

    def _get_master_name(self, asset_type):

        asset_map_dict = {
            "character": "CHAR",
            "prop": "PROP",
            "set": "ENV",
            "environment": "ENV",
            "vehicle": "PROP",
            "camera": "CAM",                 
        }

        if not asset_type:
            return "ASSETS"

        return asset_map_dict.get(asset_type.lower(), asset_type.upper())


    def _link_collection(self, path, asset_name, asset_type):

        self.logger.info("========== LINK COLLECTION START ==========")
        self.logger.info(f"path: {path}")
        self.logger.info(f"asset_name: {asset_name}")
        self.logger.info(f"asset_type: {asset_type}")
        self.logger.info(f"type(asset_name): {type(asset_name)}")

        if not os.path.exists(path):
            self.logger.warning(f"Missing publish: {path}")
            return

        master_name = self._get_master_name(asset_type)
        self.logger.info(f"Master name: {master_name}")

        # Always ensure master exists
        master = bpy.data.collections.get(master_name)
        self.logger.info(f"Master collection: {master_name}")

        if not master:
            master = bpy.data.collections.new(master_name)
            bpy.context.scene.collection.children.link(master)

        # -----------------------------------------
        # CHECK IF SAME ASSET ALREADY LINKED
        # -----------------------------------------
        self.logger.info(f"asset_name : {master.children.get(asset_name)}")

        existing = None
        for child in master.children:
            if child.name.split(".")[0].lower() == asset_name.lower():
                existing = child
                break

        if existing:
            self.logger.info(f"{asset_name} already linked in {master_name} → skipping")
            return

        with bpy.data.libraries.load(path, link=True) as (data_from, data_to):

            self.logger.info(f"Available collections in file: {list(data_from.collections)}")

            match = None

            for col in data_from.collections:
                if col.lower() == asset_name.lower():
                    match = col
                    self.logger.info(f"Matched collection: {match}")
                    break

            if not match:
                self.logger.warning(f"No matching collection for {asset_name}")
                self.logger.info(f"Available: {data_from.collections}")
                return

            data_to.collections = [match]

        linked_col = data_to.collections[0]

        for col in data_to.collections:
            if col.name not in master.children:
                master.children.link(col)

        self.logger.info(f"Linked asset: {match}")

        override_col = self._create_collection_override(linked_col, master)

        self.logger.info(f"Override collection: {override_col}")

        # -----------------------------
        # AUTO ENTER POSE MODE
        # -----------------------------
        if override_col and asset_type == "character":
            self.logger.info("Character detected → entering pose mode")
            self._auto_pose_rig(override_col)
        else:
            self.logger.info("Not a character → skipping pose mode")


    def _create_collection_override(self, linked_collection, master_collection):

        scene = bpy.context.scene

        if not linked_collection.library:
            self.logger.warning("Collection is not linked")
            return None

        # Create override
        override = linked_collection.override_hierarchy_create(
            scene,
            bpy.context.view_layer,
            do_fully_editable=True
        )

        if linked_collection.name in master_collection.children:
            master_collection.children.unlink(linked_collection)

        self.logger.info(f"Override created: {override.name}")

        return override

    def _auto_pose_rig(self, collection):

        bpy.ops.object.select_all(action='DESELECT')

        for obj in collection.all_objects:

            if obj.type == "ARMATURE" and obj.override_library:
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)

                bpy.ops.object.mode_set(mode='POSE')

                self.logger.info(f"Pose mode ready: {obj.name}")
                return

        self.logger.warning("No overriden rig found for pose mode")

    def _remove_default_collections(self):

        default_collection_names = {"Collection"}

        for col in list(bpy.data.collections):
            if col.name in default_collection_names:

                saved_name = col.name  # 👈 save before any removal

                # Unlink from scene first
                if col.name in bpy.context.scene.collection.children:
                    bpy.context.scene.collection.children.unlink(col)

                # Remove the collection itself
                bpy.data.collections.remove(col)
                self.logger.info(f"Removed default collection: {saved_name}")


    def _setup_simplify(self):
        """
        Enable Render > Simplify on scene open and apply
        viewport/render subdivision limits to speed up interaction.
        """

        scene = bpy.context.scene

        scene.render.use_simplify = True

        # Viewport: low subdivision for fast navigation
        scene.render.simplify_subdivision = 0
        scene.render.simplify_child_particles = 0.2
        scene.render.simplify_volumes = 0.0

        # Render: moderate quality for preview renders
        scene.render.simplify_subdivision_render = 2
        scene.render.simplify_child_particles_render = 0.5

        self.logger.info(
            "Simplify enabled → Viewport subdiv: 0 | Render subdiv: 2"
        )

