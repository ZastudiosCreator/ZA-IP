# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


import bpy
import os
import sgtk



__author__ = "Diego Garcia Huerta"
__contact__ = "https://www.linkedin.com/in/diegogh/"


HookClass = sgtk.get_hook_baseclass()

class SceneOperation(HookClass):
    """
    Hook called to perform an operation with the
    current scene
    """

    def execute(
        self,
        operation,
        file_path,
        context,
        parent_action,
        file_version,
        read_only,
        **kwargs
    ):
        """
        Main hook entry point

        :param operation:       String
                                Scene operation to perform

        :param file_path:       String
                                File path to use if the operation
                                requires it (e.g. open)

        :param context:         Context
                                The context the file operation is being
                                performed in.

        :param parent_action:   This is the action that this scene operation is
                                being executed for.  This can be one of:
                                - open_file
                                - new_file
                                - save_file_as
                                - version_up

        :param file_version:    The version/revision of the file to be opened.  If this is 'None'
                                then the latest version should be opened.

        :param read_only:       Specifies if the file should be opened read-only or not

        :returns:               Depends on operation:
                                'current_path' - Return the current scene
                                                 file path as a String
                                'reset'        - True if scene was reset to an empty
                                                 state, otherwise False
                                all others     - None
        """

        print(
            operation,
            file_path,
            context,
            parent_action,
            file_version,
            read_only,
            **kwargs
        )
        if operation == "current_path":
            return bpy.data.filepath

        elif operation == "open":
            bpy.ops.wm.open_mainfile(filepath=file_path)

            # run after file loads
            bpy.app.timers.register(
                lambda: self._post_open(context), first_interval=0.2
            )


        elif operation == "save":
            bpy.ops.wm.save_mainfile("EXEC_AREA")

        elif operation == "save_as":
            bpy.ops.wm.save_mainfile(filepath=file_path)

        elif operation == "reset":
            if bpy.data.is_dirty:

                # Import Qt ONLY when needed
                engine = sgtk.platform.current_engine()
                QtGui = engine.import_module("qt").QtGui

                res = QtGui.QMessageBox.question(
                    None,
                    "Save your scene?",
                    "Your scene has unsaved changes. Save before proceeding?",
                    QtGui.QMessageBox.Yes
                    | QtGui.QMessageBox.No
                    | QtGui.QMessageBox.Cancel,
                )

                if res == QtGui.QMessageBox.Cancel:
                    return False
                elif res == QtGui.QMessageBox.Yes:
                    scene_name = bpy.data.filepath
                    if not scene_name:
                        bpy.ops.wm.save_mainfile("INVOKE_AREA")
                    else:
                        bpy.ops.wm.save_mainfile(filepath=scene_name)

            bpy.ops.wm.read_homefile()

            bpy.app.timers.register(
                lambda: self._post_open(context), first_interval=0.2
            )

            return True

    def _post_open(self, ctx):

        if not ctx.entity or ctx.entity["type"] != "Shot":
            return None

        step = ctx.step["name"].lower() if ctx.step else ""

        if step not in ["layout", "animation"]:
            return None

        self._process_shot(ctx)

        return None  # required for timer

    def _process_shot(self, ctx):

        sg = self.parent.shotgun

        shot = sg.find_one(
            "Shot",
            [["id", "is", ctx.entity["id"]]],
            [
                "sg_cut_in",
                "sg_cut_out",
                "assets",
                "assets.Asset.sg_asset_type",
            ],
        )

        if not shot:
            return

        self._apply_frame_range(shot, ctx)
        self._remove_default_objects()

        if ctx.step and ctx.step["name"].lower() == "animation":
            self._setup_default_asset_libraries()
            self._set_timeline_asset_library()
            # self._build_asset_libraries_from_shot(shot)

        # layout only builds assets
        if ctx.step and ctx.step["name"].lower() == "layout":

            for asset in shot.get("assets", []):

                latest = self._get_latest_asset_publish(asset)
                self.logger.info(f"latest {latest}")

                if latest:
                    asset_type = self._get_asset_type(asset)
                    self.logger.info(f"asset_type {asset_type}")
                    self._link_collection(latest, asset["name"], asset_type)

    def _set_timeline_asset_library(self):

        screen = bpy.context.window.screen

        for area in screen.areas:

            if area.type != "DOPESHEET_EDITOR":
                continue

            for space in area.spaces:

                if space.type != "DOPESHEET_EDITOR":
                    continue

                # -----------------------------
                # 1️⃣ Set asset library safely
                # -----------------------------
                if hasattr(space, "asset_library_reference"):
                    space.asset_library_reference = "Animation Library"

                # -----------------------------
                # 2️⃣ Show asset shelf safely
                # -----------------------------
                if hasattr(space, "show_region_asset_shelf"):
                    space.show_region_asset_shelf = True
                else:
                    # Blender 4.x fallback via operator
                    try:
                        override = {
                            "window": bpy.context.window,
                            "screen": screen,
                            "area": area,
                            "region": next(
                                r for r in area.regions if r.type == "WINDOW"
                            ),
                        }

                        bpy.ops.screen.region_toggle(
                            override,
                            region_type="ASSET_SHELF"
                        )

                    except Exception as e:
                        self.logger.debug(f"Asset shelf toggle failed: {e}")

                self.logger.info(
                    "Timeline asset shelf set to Animation Library"
                )

    def _setup_default_asset_libraries(self):

        libraries = [
            ("Animation Library", r"N:/projects/mtb/library/animation_library"),
            ("Pose Library", r"N:/projects/mtb/library/pose_library"),
        ]

        prefs = bpy.context.preferences.filepaths

        for lib_name, lib_path in libraries:

            # 1️⃣ create folder if missing
            os.makedirs(lib_path, exist_ok=True)

            # 2️⃣ check if already registered
            exists = False
            for lib in prefs.asset_libraries:
                if os.path.normpath(lib.path) == os.path.normpath(lib_path):
                    exists = True
                    break

            # 3️⃣ create if not exists
            if not exists:
                new_lib = prefs.asset_libraries.new(name=lib_name)
                new_lib.path = lib_path
                self.logger.info(f"Created asset library: {lib_name}")

    def _get_asset_type(self, asset):

        sg = self.parent.shotgun

        data = sg.find_one(
            "Asset",
            [["id", "is", asset["id"]]],
            ["sg_asset_type"]
        )

        if data and data.get("sg_asset_type"):
            return data["sg_asset_type"]

        return None


    def _get_latest_asset_publish(self, asset):

        sg = self.parent.shotgun

        data = sg.find(
            "PublishedFile",
            [["entity", "is", asset]],
            ["path", "version_number"],
            order=[{"field_name": "version_number", "direction": "desc"}],
            limit=1,
        )

        if data:
            return data[0]["path"]["local_path"]

        return None

    def _remove_default_objects(self):

        default_names = {"Cube", "Light", "Camera"}

        for obj in list(bpy.data.objects):
            if obj.name in default_names:
                bpy.data.objects.remove(obj, do_unlink=True)


    def _apply_frame_range(self, shot, ctx):

        scene = bpy.context.scene

        cut_in = shot.get("sg_cut_in")
        cut_out = shot.get("sg_cut_out")

        if cut_in and cut_out:
            scene.frame_start = cut_in
            scene.frame_end = cut_out
            scene.frame_set(cut_in)

        project = self.parent.shotgun.find_one(
            "Project",
            [["id", "is", ctx.project["id"]]],
            ["sg_fps"],
        )

        if project and project.get("sg_fps"):
            scene.render.fps = int(project["sg_fps"])
            self.logger.info(f"FPS set from Project → {project['sg_fps']}")

        self.logger.info(
            f"Frame range applied → {cut_in} to {cut_out}"
        )

    def _get_master_name(self, asset_type):

        asset_map_dict = {
            "character": "CHAR",
            "prop": "PROP",
            "set": "ENV",
            "environment": "ENV",
            "vehicle": "PROP",
        }

        if not asset_type:
            return "ASSETS"

        return asset_map_dict.get(asset_type.lower(), asset_type.upper())


    def _link_collection(self, path, asset_name, asset_type):

        if not os.path.exists(path):
            self.logger.warning(f"Missing publish: {path}")
            return

        master_name = self._get_master_name(asset_type)

        if bpy.data.collections.get(master_name):
            self.logger.info(f"{master_name} already exists → skipping link")
            return

        master = bpy.data.collections.get(master_name)
        if not master:
            master = bpy.data.collections.new(master_name)
            bpy.context.scene.collection.children.link(master)

        with bpy.data.libraries.load(path, link=True) as (data_from, data_to):

            match = None

            for col in data_from.collections:
                if col.lower() == asset_name.lower():
                    match = col
                    break

            if not match:
                self.logger.warning(f"No matching collection for {asset_name}")
                self.logger.info(f"Available: {data_from.collections}")
                return

            data_to.collections = [match]

        linked_col = data_to.collections[0]

        for col in data_to.collections:
            if col.name not in master.children:
                master.children.link(col)

        self.logger.info(f"Linked asset: {match}")

        override_col = self._create_collection_override(linked_col, master)

        self.logger.info(f"Override collection: {override_col}")

        # -----------------------------
        # AUTO ENTER POSE MODE
        # -----------------------------
        if override_col:
            self._auto_pose_rig(override_col)


    def _create_collection_override(self, linked_collection, master_collection):

        scene = bpy.context.scene

        if not linked_collection.library:
            self.logger.warning("Collection is not linked")
            return None

        # Create override
        override = linked_collection.override_hierarchy_create(
            scene,
            bpy.context.view_layer,
            do_fully_editable=True
        )

        # 🔥 Remove original linked instance from the scene
        if linked_collection.name in master_collection.children:
            master_collection.children.unlink(linked_collection)

        self.logger.info(f"Override created: {override.name}")

        return override

    def _auto_pose_rig(self, collection):

        bpy.ops.object.select_all(action='DESELECT')

        for obj in collection.all_objects:

            if obj.type == "ARMATURE" and obj.override_library:
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)

                bpy.ops.object.mode_set(mode='POSE')

                self.logger.info(f"Pose mode ready: {obj.name}")
                return

        self.logger.warning("No overriden rig found for pose mode")


    def _build_asset_libraries_from_shot(self, shot):

        base_path = r"N:/projects/mtb/library"

        if os.path.exists(base_path):

            for asset in shot.get("assets", []):

                asset_name = asset["name"]

                asset_library_path = os.path.join(base_path, asset_name)

                # 1️⃣ create asset folder if missing
                if not os.path.exists(asset_library_path):
                    os.makedirs(asset_library_path)
                    self.logger.info(f"Created folder: {asset_library_path}")

                # 2️⃣ register as Blender asset library
                self._ensure_asset_library(asset_name, asset_library_path)
        else:
            self.logger.warning(f"No asset library found for {shot.name}")


    def _ensure_asset_library(self, lib_name, lib_path):

        prefs = bpy.context.preferences.filepaths

        # check if already registered
        for lib in prefs.asset_libraries:
            if os.path.normpath(lib.path) == os.path.normpath(lib_path):
                self.logger.info(f"Asset library already exists: {lib_name}")
                return

        # create new library
        new_lib = prefs.asset_libraries.new(name=lib_name)
        new_lib.path = lib_path

        self.logger.info(f"Created asset library: {lib_name} → {lib_path}")







